# Warehouse Consumable

Istilah untuk penyerahan master dan pengosongan data operasional Warehouse.

## Bahasa domain

**Master consumable**:
Identitas dan atribut barang beserta kategori, foto, dan batas persediaan.

**Saldo stok**:
Jumlah persediaan serta rinciannya menurut lokasi dan kondisi Baru/Bekas.

**Transaksi Warehouse**:
Pergerakan stok, dokumen penerimaan, riwayat shipment, rincian pemakaian mesin, dan log verifikasi.

**Sequence Warehouse**:
Penghitung nomor dokumen penerimaan atau transaksi stok dalam satu tahun.

**Restricted verifier**:
Akun yang tercatat untuk memverifikasi operasi stok terbatas.
