# Paket Outstanding Material

Paket ini berisi source aktif modul Outstanding Material untuk aplikasi Laravel Fastware ADSI, termasuk pengelolaan material berbasis invoice, import/export Excel, dokumen Packing List/MTC, akses Sales, dan penghapusan invoice permanen yang terkonfirmasi.

## Isi utama

- Source modul Laravel pada `app/`, `public/`, dan `resources/`.
- Tiga file shared versi penuh pada path finalnya: `routes/web.php`, `app/Enums/ProcurementMenuAccessGroup.php`, dan `resources/views/layout.blade.php`.
- SQL fresh-install tanpa data pada `database/sql/`.
- `DEPLOY.md`, `INTEGRATION.md`, `MANIFEST.txt`, dan `SHA256SUMS.txt`.

Paket tidak berisi `vendor`, `.env`, dokumen upload, data database, test, ataupun migration Laravel. Tiga file shared adalah versi penuh yang sudah mengeluarkan route dan menu Warehouse, karena Warehouse masih dalam pengembangan.

## Build ulang

Jalankan dari root repository:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deploy-outstanding-material\build-outstanding-material-package.ps1
```

ZIP hasil berada pada `deploy-outstanding-material/artifacts/OUTSTANDING-MATERIAL-20260818.zip`.
