@props(['active'])

<main id="main" class="main km-app">
    <a class="km-skip-link" href="#km-main-content">Lewati navigasi KM</a>

    <div class="km-workspace">
        <div class="km-sidebar-toggle-row">
            <div>
                <span class="km-sidebar-kicker">Knowledge Management</span>
                <span class="fw-semibold">Workspace KM</span>
            </div>
            <button class="btn btn-outline-primary btn-sm" type="button"
                data-bs-toggle="offcanvas" data-bs-target="#kmWorkspaceNavigation"
                aria-controls="kmWorkspaceNavigation" aria-label="Buka navigasi Knowledge Management">
                <i class="bi bi-list" aria-hidden="true"></i>
                <span>Menu</span>
            </button>
        </div>

        <aside class="offcanvas offcanvas-start km-sidebar" tabindex="-1" id="kmWorkspaceNavigation"
            aria-labelledby="kmWorkspaceNavigationLabel">
            <div class="offcanvas-header">
                <div>
                    <span class="km-sidebar-kicker">Knowledge Management</span>
                    <h2 class="km-sidebar-title" id="kmWorkspaceNavigationLabel">Workspace KM</h2>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Tutup navigasi"></button>
            </div>
            <div class="offcanvas-body p-0">
                <div class="d-none d-lg-block px-4 pt-4 pb-2">
                    <span class="km-sidebar-kicker">Knowledge Management</span>
                    <p class="km-sidebar-title">Workspace KM</p>
                </div>
                <nav class="km-sidebar-nav" aria-label="Navigasi Knowledge Management">
                    @can('viewAny', \App\Models\KmPengajuan::class)
                        <a class="km-sidebar-link" href="{{ route('dsKnowlege') }}"
                            @if ($active === 'library') aria-current="page" @endif>
                            <i class="bi bi-collection" aria-hidden="true"></i>
                            <span>Library</span>
                        </a>
                    @endcan

                    @can('create', \App\Models\KmPengajuan::class)
                        <a class="km-sidebar-link" href="{{ route('pengajuanKM') }}"
                            @if ($active === 'submissions') aria-current="page" @endif>
                            <i class="bi bi-file-earmark-text" aria-hidden="true"></i>
                            <span>Pengajuan Saya</span>
                        </a>
                    @endcan

                    @can('bulkApprove', \App\Models\KmPengajuan::class)
                        <a class="km-sidebar-link" href="{{ route('persetujuanKM') }}"
                            @if ($active === 'approvals') aria-current="page" @endif>
                            <i class="bi bi-check2-square" aria-hidden="true"></i>
                            <span>Persetujuan</span>
                        </a>
                    @endcan

                    @can('viewPopularAnalytics', \App\Models\KmPengajuan::class)
                        <a class="km-sidebar-link" href="{{ route('km.analytics.popular') }}"
                            @if ($active === 'popular') aria-current="page" @endif>
                            <i class="bi bi-bar-chart" aria-hidden="true"></i>
                            <span>Materi Populer</span>
                        </a>
                    @endcan
                </nav>
            </div>
        </aside>

        <div class="km-main-panel" id="km-main-content" tabindex="-1">
            <div class="km-shell-utility">
                <div class="dropdown">
                    <button type="button" class="btn btn-outline-secondary km-notification-trigger"
                        id="km-notification-trigger" data-bs-toggle="dropdown" data-bs-auto-close="outside"
                        aria-expanded="false" aria-controls="km-notification-menu"
                        aria-label="Buka notifikasi Knowledge Management">
                        <i class="bi bi-bell" aria-hidden="true"></i>
                        <span class="d-none d-sm-inline">Notifikasi</span>
                        <span class="km-notification-badge" data-km-notification-badge hidden></span>
                    </button>

                    <div class="dropdown-menu dropdown-menu-end km-notification-menu"
                        id="km-notification-menu" aria-labelledby="km-notification-trigger">
                        <div class="km-notification-header">
                            <div>
                                <strong>Notifikasi KM</strong>
                                <span class="km-notification-summary" data-km-notification-summary>Memuat...</span>
                            </div>
                            <button type="button" class="btn btn-link btn-sm" data-km-notification-read-all disabled>
                                Tandai semua dibaca
                            </button>
                        </div>
                        <div class="km-notification-list" data-km-notification-list aria-live="polite" aria-busy="true">
                            <div class="km-notification-loading" data-km-notification-loading>
                                <span class="spinner-border spinner-border-sm" aria-hidden="true"></span>
                                <span>Memuat notifikasi...</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{ $slot }}
        </div>
    </div>

    <x-km.feedback :dialogs="true" />
</main>

<script>
window.kmShellConfig = {
    csrfToken: @js(csrf_token()),
    indexUrl: @js(route('km.notifications.index')),
    readUrlTemplate: @js(route('km.notifications.read', ['notification' => '__KM_NOTIFICATION__'])),
    readAllUrl: @js(route('km.notifications.read-all')),
    documentUrlTemplate: @js(route('dsKnowlege', ['document' => '__KM_ID__'])),
};
</script>

@push('scripts')
    @vite('resources/js/km/shell.js')
@endpush
