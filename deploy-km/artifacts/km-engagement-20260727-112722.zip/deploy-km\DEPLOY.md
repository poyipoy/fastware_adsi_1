# Deployment KM Engagement Foundation

Dokumen ini adalah runbook production untuk fase 1–9 `plan-refactor-km.md`. Implementasi saat ini belum menjalankan migration pada database aplikasi lokal dan belum melakukan commit atau push.

## Prinsip Wajib

- Buat backup database terverifikasi sebelum DDL atau backfill.
- Deploy ke maintenance window dan siapkan rollback application release sebelumnya.
- Jalankan **satu jalur schema saja**. Runbook production ini memakai empat file SQL manual. Jangan menjalankan `php artisan migrate` untuk empat migration `130001`–`130004` setelah SQL dijalankan; setiap SQL sudah mendaftarkan row pada tabel `migrations`.
- Keempat SQL adalah satu release group: `130001` → `130002` → `130003` → `130004`. Jangan mengaktifkan code baru pada schema parsial.
- Jangan menjalankan rollback SQL production tanpa backup dan persetujuan stakeholder. Rollback code lebih dahulu.

## Gate Migration KM Existing

Sebelum deployment, periksa tabel `migrations` di production. Sebelas migration KM existing berikut harus sudah berstatus ran:

1. `2026_07_18_100001_baseline_knowledge_management_schema`
2. `2026_07_18_100002_harden_knowledge_management_constraints`
3. `2026_07_18_100003_create_km_approval_events_table`
4. `2026_07_18_100004_add_private_file_metadata_to_km_pengajuans`
5. `2026_07_18_110001_create_km_bookmarks_table`
6. `2026_07_18_110002_add_km_thumbnail_pipeline_fields_to_km_pengajuans`
7. `2026_07_18_110003_create_km_tags_table`
8. `2026_07_18_110004_create_km_document_tag_table`
9. `2026_07_18_110005_create_km_document_authors_table`
10. `2026_07_18_110006_add_km_authoring_metadata_to_km_pengajuans`
11. `2026_07_18_120001_add_km_metadata_fulltext_index_to_km_pengajuans`

Jika satu saja belum ada, **hentikan deployment**. Status production belum dikonfirmasi pada sesi implementasi ini dan SQL konsolidasi sebelas migration lama tidak dibuat tanpa bukti schema target. Audit schema serta rencanakan baseline deployment terpisah.

## Preflight Production

1. Catat commit/release aktif, versi PHP/MySQL, `APP_ENV`, nama database, dan storage disk KM.
2. Pastikan MySQL 8.0+, tabel `users`, `km_pengajuans`, `km_transaksis`, `km_insights`, serta migration existing di atas tersedia.
3. Audit duplicate/orphan/type dan named constraint. Setiap query PRECHECK pada empat SQL baru harus memberi hasil yang disebutkan dalam komentar file.
4. Validasi coverage organisasi aktif: `user_job_positions` → `mst_job_positions.department_id` → `mst_departments.name`. `users.section` hanya fallback snapshot.
5. Simpan backup database dan uji bahwa backup dapat dibaca.
6. Jalankan build sebelum membuat paket: `npm.cmd run build`.
7. Buat paket dengan `powershell -ExecutionPolicy Bypass -File deploy-km/make-deploy-zip.ps1 -BaselineRef <commit-baseline>`.

## Urutan Schema Manual

Jalankan satu per satu dan periksa seluruh SELECT verifikasi sebelum melanjutkan:

1. `database/migrations/2026_07_27_130001_create_km_notifications_table.sql`
2. `database/migrations/2026_07_27_130002_add_km_reading_progress_to_km_transaksis.sql`
3. `database/migrations/2026_07_27_130003_extend_km_insights_social.sql`
4. `database/migrations/2026_07_27_130004_create_km_point_ledger_table.sql`

Setelah `130004`, query `drift_user_count` harus menghasilkan `0`. Bila tidak, hentikan aktivasi code dan reconcile data secara eksplisit; jangan mengubah `users.km_total_poin` dengan query ad hoc.

## Deploy File

1. Ekstrak paket dengan struktur path tetap dari root aplikasi.
2. Salin seluruh `public/build/**`, bukan hanya file manifest. Hash asset harus tetap cocok dengan `public/build/manifest.json`.
3. File berikut adalah source legacy yang dihapus oleh fase stabilisasi dan tidak berada dalam ZIP. Backup lalu hapus secara eksplisit dari target:
   - `app/Http/Controllers/1225_KmPengajuanController.php`
   - `app/Services/Dashboard/KnowledgeManagementDashboardService.php`
4. Pastikan partial yatim berikut tidak tertinggal bila pernah ada sebagai file manual/untracked di server:
   - `resources/views/knowlege_management/partials/document-form.blade.php`
   - `resources/views/knowlege_management/partials/approval-actions.blade.php`
5. Jangan salin `.env`, test, factory, upload pengguna, cache, credential, atau private document dari workstation.

## Environment dan Runtime

Pertahankan nilai production yang sudah disetujui untuk:

- `KM_DISK=km_private`
- `KM_PDF_THUMBNAIL_ENABLED`
- `KM_PDFTOPPM_BINARY` dengan path binary production yang tervalidasi

Tidak ada queue worker baru pada release ini. Reminder SLA memiliki lazy sweep saat halaman approval dibuka, tetapi scheduler tetap direkomendasikan. Pastikan cron Laravel menjalankan `php artisan schedule:run` setiap menit; schedule akan memanggil reminder pada hari kerja pukul 08:00 dan reconciliation pukul 08:15 zona aplikasi.

## Cache dan Verifikasi

1. Jalankan `php artisan optimize:clear`.
2. Jalankan `php artisan route:list --path=km` dan pastikan route notification, progress, insight, serta legacy compatibility tersedia.
3. Jalankan `php artisan view:cache`.
4. Jalankan `php artisan km:health --json` dan `php artisan km:readiness --json`; hentikan rollout pada mandatory FAIL.
5. Jalankan `php artisan km:reconcile-points --json`; drift harus kosong.
6. Jalankan `php artisan km:send-approval-reminders --json` dua kali dan pastikan pemanggilan kedua tidak menambah notification untuk event yang sama.

## Smoke Test

- Submit draft → approver eligible menerima notification → approve → owner menerima notification dan ledger `+25` tepat sekali.
- Buka PDF → resume halaman terakhir → progress meningkat monotonic → completion hanya aktif setelah minimal 90% halaman unik dan waktu aktif → ledger `+5` tepat sekali.
- Buat root/reply insight, ganti reaction, mention user yang berhak, edit dalam 30 menit, dan moderasi dengan alasan.
- Tetapkan tiga Insight Pilihan; request keempat harus ditolak dan re-feature tidak menambah poin kedua kali.
- Toggle leaderboard Global/Departemen; cohort departemen kurang dari lima harus dimasking.
- Antrean approval menampilkan umur hari kerja, sort oldest/newest, badge Terlambat, dan reminder idempotent.
- Uji forbidden path untuk user yang tidak memiliki akses dokumen.
- Uji viewport 360, 768, 1024, 1280, dan 1440 px; keyboard/focus, zoom 200%, serta reduced motion.

## Rollback

1. Kembalikan application code dan seluruh `public/build/**` ke release sebelumnya.
2. Pulihkan dua file legacy hanya bila release sebelumnya masih mereferensikannya.
3. Jalankan `php artisan optimize:clear`, route check, dan smoke release lama.
4. Biarkan tabel/kolom additive serta ledger tetap ada. Data notification, progress, insight, dan ledger tidak dihapus pada rollback code.
5. Bila database rollback benar-benar diwajibkan, gunakan bagian rollback yang masih dikomentari di setiap SQL hanya setelah aplikasi lama aktif, backup tersedia, dependency diperiksa, dan stakeholder menyetujui kehilangan data terkait.

Daftar file production berada di `deploy-km/manifest.txt`. Tests dan factories sengaja tidak termasuk paket.
