import { notify } from './ui-feedback.js';

const config = window.kmConfig ?? {};
const reactionLabels = {
    helpful: 'Membantu',
    insightful: 'Mencerahkan',
    agree: 'Setuju',
};

let modalElement = null;
let modal = null;
let currentDocumentId = null;
let currentPage = 1;
let lastPage = 1;
let editingInsightId = null;
let triggeringElement = null;

function csrfToken() {
    return config.csrfToken ?? document.querySelector('meta[name="csrf-token"]')?.content ?? '';
}

function endpoint(template, placeholder, value) {
    return String(template ?? '').replace(placeholder, String(value));
}

function documentEndpoint(template) {
    return endpoint(template, '__KM_DOCUMENT__', currentDocumentId);
}

function insightEndpoint(template, insightId) {
    return endpoint(template, '__KM_INSIGHT__', insightId);
}

async function jsonResponse(response) {
    const payload = await response.json().catch(() => ({}));
    if (! response.ok || payload.success === false) {
        const validationMessage = Object.values(payload.errors ?? {}).flat().find(Boolean);
        throw new Error(validationMessage ?? payload.message ?? 'Permintaan insight belum dapat diproses.');
    }

    return payload;
}

async function request(url, options = {}) {
    const response = await fetch(url, {
        ...options,
        headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken(),
            ...options.headers,
        },
    });

    return jsonResponse(response);
}

function node(tag, className = '', text = '') {
    const created = document.createElement(tag);
    if (className) {
        created.className = className;
    }
    if (text) {
        created.textContent = text;
    }

    return created;
}

function actionButton(label, action, insightId, className = 'btn btn-link btn-sm') {
    const button = node('button', className, label);
    button.type = 'button';
    button.dataset.kmInsightAction = action;
    button.dataset.insightId = String(insightId);

    return button;
}

function formatDate(value) {
    if (! value) {
        return '-';
    }
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
        return '-';
    }

    return new Intl.DateTimeFormat('id-ID', {
        dateStyle: 'medium',
        timeStyle: 'short',
    }).format(date);
}

function setFeedback(message = '', tone = 'info') {
    const feedback = modalElement?.querySelector('[data-km-insight-feedback]');
    if (! feedback) {
        return;
    }
    feedback.textContent = message;
    feedback.dataset.tone = tone;
}

function renderLoading() {
    const list = modalElement.querySelector('[data-km-insight-list]');
    list.replaceChildren();
    list.setAttribute('aria-busy', 'true');
    const loading = node('div', 'km-loading-state');
    const spinner = node('span', 'spinner-border spinner-border-sm');
    spinner.setAttribute('aria-hidden', 'true');
    loading.append(spinner, node('span', '', 'Memuat diskusi...'));
    list.append(loading);
}

function renderEmpty() {
    const empty = node('div', 'km-empty-state');
    const icon = node('i', 'bi bi-chat-square-text km-empty-state__icon');
    icon.setAttribute('aria-hidden', 'true');
    empty.append(
        icon,
        node('h3', 'km-empty-state__title', 'Belum ada insight'),
        node('p', 'km-empty-state__description', 'Jadilah yang pertama membagikan pembelajaran dari materi ini.'),
    );

    return empty;
}

function renderDeletePanel(insightId) {
    const panel = node('div', 'km-insight-delete-panel mt-3');
    panel.dataset.kmInsightDeletePanel = String(insightId);
    const id = `km-insight-delete-reason-${insightId}`;
    const label = node('label', 'form-label', 'Alasan penghapusan (wajib untuk moderator)');
    label.htmlFor = id;
    const input = node('textarea', 'form-control');
    input.id = id;
    input.rows = 2;
    input.maxLength = 500;
    input.dataset.kmInsightDeleteReason = '';
    const controls = node('div', 'd-flex justify-content-end gap-2 mt-2');
    controls.append(
        actionButton('Batal', 'cancel-delete', insightId, 'btn btn-outline-secondary btn-sm'),
        actionButton('Hapus insight', 'confirm-delete', insightId, 'btn btn-danger btn-sm'),
    );
    panel.append(label, input, controls);

    return panel;
}

function renderInsight(insight, isReply = false) {
    const card = node('article', 'km-insight-card');
    card.dataset.insightId = String(insight.id);
    card.dataset.reply = String(isReply);
    card.dataset.featured = String(insight.featured === true);

    const header = node('div', 'km-insight-card__header');
    const identity = node('div');
    const author = node('strong', '', insight.author?.name ?? 'Pengguna tidak tersedia');
    const meta = node(
        'span',
        'km-insight-card__meta ms-2',
        `${formatDate(insight.created_at)}${insight.edited_at ? ' Â· diedit' : ''}`,
    );
    identity.append(author, meta);
    header.append(identity);
    if (insight.featured) {
        const featuredDetails = [
            insight.featured_by ? `oleh ${insight.featured_by}` : '',
            insight.featured_at ? formatDate(insight.featured_at) : '',
        ].filter(Boolean).join(' Â· ');
        const featured = node(
            'span',
            'km-status km-status--pending',
            `Insight Pilihan${featuredDetails ? ` Â· ${featuredDetails}` : ''}`,
        );
        header.append(featured);
    }
    card.append(header);

    const content = node('p', 'km-insight-card__content', insight.content ?? '');
    card.append(content);
    if (insight.delete_reason) {
        card.append(node('p', 'km-insight-card__meta', `Alasan penghapusan: ${insight.delete_reason}`));
    }
    if ((insight.mentions ?? []).length > 0) {
        const mentions = insight.mentions.map((mention) => `@${mention.name}`).join(', ');
        card.append(node('p', 'km-insight-mentions', `Mention: ${mentions}`));
    }

    if (! insight.deleted) {
        const reactions = node('div', 'km-insight-reactions');
        (config.reactionTypes ?? []).forEach((reaction) => {
            const count = Number(insight.reactions?.[reaction] ?? 0);
            const button = actionButton(
                `${reactionLabels[reaction] ?? reaction} (${count})`,
                'reaction',
                insight.id,
                'btn btn-outline-secondary btn-sm km-insight-reaction',
            );
            button.dataset.reaction = reaction;
            button.setAttribute('aria-pressed', String(insight.viewer_reaction === reaction));
            reactions.append(button);
        });
        card.append(reactions);

        const actions = node('div', 'km-insight-card__actions');
        if (insight.permissions?.reply) {
            const reply = actionButton('Balas', 'reply', insight.id);
            reply.dataset.authorName = insight.author?.name ?? 'pengguna';
            actions.append(reply);
        }
        if (insight.permissions?.edit) {
            const edit = actionButton('Edit', 'edit', insight.id);
            edit.dataset.content = insight.content ?? '';
            edit.dataset.mentionIds = JSON.stringify(
                (insight.mentions ?? []).map((mention) => Number(mention.id)),
            );
            actions.append(edit);
        }
        if (insight.permissions?.feature) {
            actions.append(actionButton(
                insight.featured ? 'Batalkan pilihan' : 'Jadikan pilihan',
                insight.featured ? 'unfeature' : 'feature',
                insight.id,
            ));
        }
        if (insight.permissions?.delete) {
            actions.append(actionButton('Hapus', 'delete', insight.id, 'btn btn-link btn-sm text-danger'));
        }
        card.append(actions);
    }

    (insight.replies ?? []).forEach((reply) => card.append(renderInsight(reply, true)));

    return card;
}

async function loadInsights({ append = false } = {}) {
    if (! currentDocumentId) {
        return;
    }
    if (! append) {
        currentPage = 1;
        renderLoading();
    }

    const requestedDocumentId = currentDocumentId;
    const list = modalElement.querySelector('[data-km-insight-list]');
    const more = modalElement.querySelector('[data-km-insight-more]');
    more.disabled = true;
    try {
        const url = new URL(documentEndpoint(config.insightIndexUrlTemplate), window.location.origin);
        url.searchParams.set('page', String(currentPage));
        url.searchParams.set('per_page', '10');
        const focusInsightId = Number.parseInt(
            new URLSearchParams(window.location.search).get('insight') ?? '',
            10,
        );
        if (Number.isInteger(focusInsightId)) {
            url.searchParams.set('focus_id', String(focusInsightId));
        }
        const payload = await request(url.toString());
        if (currentDocumentId !== requestedDocumentId) {
            return;
        }
        if (! append) {
            list.replaceChildren();
        }
        if (! append && payload.data.length === 0) {
            list.append(renderEmpty());
        } else {
            payload.data.forEach((insight) => list.append(renderInsight(insight)));
        }
        lastPage = Number(payload.meta?.last_page ?? 1);
        more.hidden = currentPage >= lastPage;
        list.setAttribute('aria-busy', 'false');
        setFeedback();
        if (! append && Number.isInteger(focusInsightId)) {
            const target = list.querySelector(`[data-insight-id="${focusInsightId}"]`);
            if (target) {
                target.tabIndex = -1;
                target.scrollIntoView({ block: 'center' });
                target.focus({ preventScroll: true });
            }
        }
    } catch (error) {
        if (currentDocumentId !== requestedDocumentId) {
            return;
        }
        if (! append) {
            list.replaceChildren();
        }
        setFeedback(error.message ?? 'Insight belum dapat dimuat.', 'danger');
        more.hidden = true;
        list.setAttribute('aria-busy', 'false');
    } finally {
        more.disabled = false;
    }
}

async function loadMentions() {
    const requestedDocumentId = currentDocumentId;
    const select = modalElement.querySelector('[data-km-insight-mentions]');
    select.replaceChildren();
    select.disabled = true;
    try {
        const payload = await request(documentEndpoint(config.insightMentionUrlTemplate));
        if (currentDocumentId !== requestedDocumentId) {
            return null;
        }
        payload.data.forEach((user) => {
            const option = node('option');
            option.value = String(user.id);
            option.textContent = `${user.name}${user.email ? ` (${user.email})` : ''}`;
            select.append(option);
        });
    } catch (error) {
        return error.message ?? 'Daftar mention belum dapat dimuat.';
    } finally {
        if (currentDocumentId === requestedDocumentId) {
            select.disabled = false;
        }
    }

    return null;
}

function resetComposer() {
    const form = modalElement.querySelector('[data-km-insight-form]');
    form.reset();
    editingInsightId = null;
    form.querySelector('[data-km-insight-parent]').value = '';
    form.querySelector('[data-km-insight-reply-context]').hidden = true;
    form.querySelector('[data-km-insight-submit]').textContent = 'Kirim insight';
    form.querySelector('[data-km-insight-mention-panel]').hidden = true;
    form.querySelector('[data-km-insight-mention-toggle]').setAttribute('aria-expanded', 'false');
}

function prepareReply(button) {
    resetComposer();
    const form = modalElement.querySelector('[data-km-insight-form]');
    form.querySelector('[data-km-insight-parent]').value = button.dataset.insightId;
    form.querySelector('[data-km-insight-reply-label]').textContent = `Membalas ${button.dataset.authorName}.`;
    form.querySelector('[data-km-insight-reply-context]').hidden = false;
    form.querySelector('[name="content"]').focus();
}

function prepareEdit(button) {
    resetComposer();
    editingInsightId = button.dataset.insightId;
    const form = modalElement.querySelector('[data-km-insight-form]');
    form.querySelector('[data-km-insight-reply-label]').textContent = 'Mengedit insight Anda.';
    form.querySelector('[data-km-insight-reply-context]').hidden = false;
    form.querySelector('[data-km-insight-submit]').textContent = 'Simpan perubahan';
    const content = form.querySelector('[name="content"]');
    content.value = button.dataset.content ?? '';
    const mentionIds = JSON.parse(button.dataset.mentionIds ?? '[]');
    if (mentionIds.length > 0) {
        form.querySelector('[data-km-insight-mention-panel]').hidden = false;
        form.querySelector('[data-km-insight-mention-toggle]').setAttribute('aria-expanded', 'true');
    }
    form.querySelectorAll('[data-km-insight-mentions] option').forEach((option) => {
        option.selected = mentionIds.includes(Number.parseInt(option.value, 10));
    });
    content.focus();
}

async function submitComposer(form) {
    const submit = form.querySelector('[data-km-insight-submit]');
    submit.disabled = true;
    submit.setAttribute('aria-busy', 'true');
    const mentionIds = [...form.querySelector('[data-km-insight-mentions]').selectedOptions]
        .map((option) => Number.parseInt(option.value, 10));
    const body = {
        content: form.querySelector('[name="content"]').value,
        mention_ids: mentionIds,
    };
    const parentId = Number.parseInt(form.querySelector('[data-km-insight-parent]').value, 10);
    if (Number.isInteger(parentId)) {
        body.parent_id = parentId;
    }

    try {
        const payload = await request(
            editingInsightId
                ? insightEndpoint(config.insightUpdateUrlTemplate, editingInsightId)
                : documentEndpoint(config.insightStoreUrlTemplate),
            {
                method: editingInsightId ? 'PATCH' : 'POST',
                body: JSON.stringify(body),
            },
        );
        notify({ title: 'Insight tersimpan', message: payload.message, tone: 'success' });
        resetComposer();
        await loadInsights();
    } catch (error) {
        setFeedback(error.message ?? 'Insight belum dapat disimpan.', 'danger');
    } finally {
        submit.disabled = false;
        submit.removeAttribute('aria-busy');
    }
}

async function mutateInsight(button) {
    const insightId = button.dataset.insightId;
    const action = button.dataset.kmInsightAction;
    button.disabled = true;
    try {
        let payload;
        if (action === 'reaction') {
            const isActive = button.getAttribute('aria-pressed') === 'true';
            payload = await request(insightEndpoint(config.insightReactionUrlTemplate, insightId), {
                method: isActive ? 'DELETE' : 'PUT',
                body: isActive ? undefined : JSON.stringify({ reaction: button.dataset.reaction }),
            });
        } else if (action === 'feature' || action === 'unfeature') {
            payload = await request(insightEndpoint(config.insightFeatureUrlTemplate, insightId), {
                method: action === 'feature' ? 'POST' : 'DELETE',
                body: JSON.stringify({}),
            });
            notify({ title: 'Status insight diperbarui', message: payload.message, tone: 'success' });
        } else if (action === 'confirm-delete') {
            const panel = button.closest('[data-km-insight-delete-panel]');
            const reason = panel.querySelector('[data-km-insight-delete-reason]').value.trim();
            payload = await request(insightEndpoint(config.insightDeleteUrlTemplate, insightId), {
                method: 'DELETE',
                body: JSON.stringify({ reason: reason || null }),
            });
            notify({ title: 'Insight dihapus', message: payload.message, tone: 'success' });
        }
        await loadInsights();
    } catch (error) {
        setFeedback(error.message ?? 'Perubahan insight belum dapat disimpan.', 'danger');
    } finally {
        button.disabled = false;
    }
}

function openDeletePanel(button) {
    const card = button.closest('.km-insight-card');
    if (! card || card.querySelector('[data-km-insight-delete-panel]')) {
        return;
    }
    card.append(renderDeletePanel(button.dataset.insightId));
    card.querySelector('[data-km-insight-delete-reason]').focus();
}

function initEventHandlers() {
    document.addEventListener('click', (event) => {
        const trigger = event.target.closest('[data-km-insights-open]');
        if (trigger) {
            triggeringElement = trigger;
            currentDocumentId = Number.parseInt(trigger.dataset.documentId, 10);
            modalElement.querySelector('#km-insight-modal-title').textContent = `Insight â€” ${trigger.dataset.title}`;
            resetComposer();
            setFeedback();
            modal.show();
            renderLoading();
            void (async () => {
                const mentionError = await loadMentions();
                await loadInsights();
                if (mentionError) {
                    setFeedback(mentionError, 'danger');
                }
            })();
            return;
        }

        const action = event.target.closest('[data-km-insight-action]');
        if (! action || ! modalElement.contains(action)) {
            return;
        }
        const type = action.dataset.kmInsightAction;
        if (type === 'reply') {
            prepareReply(action);
        } else if (type === 'edit') {
            prepareEdit(action);
        } else if (type === 'delete') {
            openDeletePanel(action);
        } else if (type === 'cancel-delete') {
            action.closest('[data-km-insight-delete-panel]')?.remove();
        } else {
            void mutateInsight(action);
        }
    });

    modalElement.querySelector('[data-km-insight-cancel-reply]').addEventListener('click', resetComposer);
    modalElement.querySelector('[data-km-insight-mention-toggle]').addEventListener('click', (event) => {
        const panel = modalElement.querySelector('[data-km-insight-mention-panel]');
        const expanded = event.currentTarget.getAttribute('aria-expanded') === 'true';
        event.currentTarget.setAttribute('aria-expanded', String(! expanded));
        panel.hidden = expanded;
        if (! expanded) {
            panel.querySelector('select')?.focus();
        }
    });
    modalElement.querySelector('[data-km-insight-form]').addEventListener('submit', (event) => {
        event.preventDefault();
        void submitComposer(event.currentTarget);
    });
    modalElement.querySelector('[data-km-insight-more]').addEventListener('click', () => {
        if (currentPage < lastPage) {
            currentPage += 1;
            void loadInsights({ append: true });
        }
    });
    modalElement.addEventListener('hidden.bs.modal', () => {
        currentDocumentId = null;
        resetComposer();
        triggeringElement?.focus();
        triggeringElement = null;
    });
}

export function initInsights() {
    modalElement = document.getElementById('km-insight-modal');
    if (! modalElement) {
        return;
    }
    modal = bootstrap.Modal.getOrCreateInstance(modalElement);
    initEventHandlers();
}
