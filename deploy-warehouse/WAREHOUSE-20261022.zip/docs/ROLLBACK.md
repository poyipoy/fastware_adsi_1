# Pemulihan

Pertahankan backup source, database, cache dan build production sebelum pemasangan.
Jika belum ada transaksi production dan pemasangan gagal, pertahankan maintenance dan pulihkan backup aplikasi/database melalui prosedur hosting. SQL schema bukan transaksi atomik dan tidak boleh diulang secara membabi buta.
Jika Warehouse sudah dipakai bertransaksi, hentikan penulisan, backup kondisi terkini dan gunakan forward fix setelah audit. Jangan menghapus transaksi atau menjalankan migration rollback/reset umum.
Saat mengembalikan aplikasi, pulihkan file bersama dari backup production dan build+manifest yang berpasangan. Jangan mengembalikan hanya satu aset ber-hash. Loader bootstrap dilepas hanya ketika kode/layout/routes Warehouse juga telah dinonaktifkan secara konsisten.
