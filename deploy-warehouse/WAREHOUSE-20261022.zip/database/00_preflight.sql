-- READ ONLY. Save the results. 01_schema repeats the blocking checks.
SELECT DATABASE() AS target_database, VERSION() AS engine_version, @@version_comment AS engine_comment;
SHOW GRANTS FOR CURRENT_USER();
SELECT TABLE_NAME, ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND (TABLE_NAME LIKE 'mst\_wh\_%' OR TABLE_NAME LIKE 'trs\_wh\_%' OR TABLE_NAME LIKE 'log\_wh\_%' OR TABLE_NAME LIKE 'wh\_%');
SELECT 5439 AS npk, (SELECT CASE WHEN COUNT(*)=1 THEN MIN(id) WHEN SUM(role_id=1)=1 THEN MAX(CASE WHEN role_id=1 THEN id END) ELSE NULL END FROM users WHERE npk=5439 AND is_active=0) AS resolved_production_user_id;
SELECT 5472 AS npk, (SELECT CASE WHEN COUNT(*)=1 THEN MIN(id) WHEN SUM(role_id=1)=1 THEN MAX(CASE WHEN role_id=1 THEN id END) ELSE NULL END FROM users WHERE npk=5472 AND is_active=0) AS resolved_production_user_id;
SELECT 5584 AS npk, (SELECT CASE WHEN COUNT(*)=1 THEN MIN(id) WHEN SUM(role_id=1)=1 THEN MAX(CASE WHEN role_id=1 THEN id END) ELSE NULL END FROM users WHERE npk=5584 AND is_active=0) AS resolved_production_user_id;
SELECT 5639 AS npk, (SELECT CASE WHEN COUNT(*)=1 THEN MIN(id) WHEN SUM(role_id=1)=1 THEN MAX(CASE WHEN role_id=1 THEN id END) ELSE NULL END FROM users WHERE npk=5639 AND is_active=0) AS resolved_production_user_id;
SELECT 5661 AS npk, (SELECT CASE WHEN COUNT(*)=1 THEN MIN(id) WHEN SUM(role_id=1)=1 THEN MAX(CASE WHEN role_id=1 THEN id END) ELSE NULL END FROM users WHERE npk=5661 AND is_active=0) AS resolved_production_user_id;
SELECT d.name, COUNT(DISTINCT a.user_id) AS active_assigned_users FROM mst_departments d JOIN mst_job_positions p ON p.department_id=d.id JOIN user_job_positions a ON a.mst_job_position_id=p.id JOIN users u ON u.id=a.user_id WHERE d.is_active=1 AND p.is_active=1 AND a.is_active=1 AND u.is_active=0 GROUP BY d.name;
