# SQL Modul HR

`hr_schema_snapshot_20260731.sql` adalah snapshot schema-only dari database lokal `dms_adasi_rev1` pada 31 Juli 2026.

Isi snapshot:

- organisasi dan job position;
- mapping user-job position dan working experience;
- People Development dan participant Sharing Knowledge;
- master serta transaksi Base Competency.

Snapshot tidak memuat `INSERT`, data karyawan, NPK, password, token, upload, atau credential.

Untuk database existing, jangan langsung mengimpor snapshot. Bandingkan schema dan jalankan migration Laravel yang belum terpasang secara terarah. Tabel `users` dan `roles` merupakan prerequisite aplikasi dan tidak dibuat oleh snapshot ini.
