# Kontrak layout aktif

Layout lengkap dalam resources/views/layout.blade.php sudah memuat hook berikut (styles dalam head, scripts sebelum penutup body):

```blade
@stack('styles')
<body class="@yield('bodyClass')">
@yield('content')
@stack('scripts')
```

Jika file layout production memiliki perubahan khusus, pertahankan hook dan menu Warehouse saat rekonsiliasi. Jangan menambahkan hook dua kali. Pertahankan Bootstrap, jQuery/DataTables dan aset shell production yang sudah dipakai aplikasi.
