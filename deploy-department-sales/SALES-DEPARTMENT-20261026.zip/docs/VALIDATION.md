# Verifikasi paket, 26 Oktober 2026

## Pemeriksaan yang dijalankan

- Rehearsal file SQL paket pada database MySQL 8.0.30 disposable berakhiran `_testing`: **7 tes / 182 assertion lulus**. Kredensial koneksi pengujian harus lokal dan nama database dijaga oleh fixture existing. Database aplikasi `dms_adasi_rev1` dan produksi tidak menjadi target impor.
- Tambahan standalone: **3 tes / 64 assertion lulus**, meliputi impor tanpa helper/file lain, mapping 1&3 / 2&4, histori tetap utuh, tidak ada tabel aplikasi baru, penolakan audit/kolom yang hilang, rollback, dan impor ulang setelah perubahan HR. Total suite paket: **10 tes / 246 assertion**.
- Kontrak hasil SQL dan command Artisan diuji terhadap fixture yang sama dengan ID berbeda dari lokal: empat department/kepala, assignment 1&3 dan 2&4, approval termasuk level 1/2, cakupan TCPD, posisi nonaktif ikut berpindah, dan tujuh tabel histori/master kompetensi tidak berubah.
- Preflight tidak mengubah data aplikasi. Konflik tujuan, kolom prasyarat hilang, target KM, tabel audit tidak kompatibel, dan actor audit ambigu ditolak.
- Kegagalan yang disisipkan setelah penulisan assignment/audit membatalkan seluruh perubahan data. DDL tabel audit file 01 terpisah dari transaksi data file 02.
- Dua koneksi membuktikan SQL menunggu lock department yang sama dengan writer aplikasi. Reimpor mempertahankan perubahan nama/assignment HR sesudah pemisahan dan tidak menambah audit.
- `split_sales_regions_only.sql` dibangun dari validasi 00, transaksi 02, dan postcheck 03, dengan helper bernama terpisah dan audit diwajibkan tersedia. Tidak mengandung bagian pembuatan tabel audit dari file 01. Verifier mencocokkan hasil generator dan menolak DDL tabel aplikasi pada standalone.
- Seluruh PHP runtime paket dilint, JavaScript diperiksa sintaksnya, dan checksum setiap file serta isi ZIP dibandingkan byte-per-byte. ZIP berisi struktur root langsung.
- Overlay route paket memuat **6 route department** yang unik dan terautentikasi; controller berasal dari folder paket. **13 template Blade** dikompilasi dan dilint.
- Salinan `routes/web.php` sengaja mengeluarkan tepat **7 rute arsip Outstanding Material** dari perubahan terpisah; sumber asli tidak diedit. Tidak ada file perubahan Warehouse/Outstanding Material, data dump, credential, workbook, snapshot private, atau dependency vendor di paket.

## Reproduksi dari workspace pengembangan

```powershell
python scripts/department-sales-release/build_package.py
$env:SALES_PACKAGE_VERIFY_BUNDLE='1'
php artisan test tests/Feature/HR/SalesDepartmentPackageSqlTest.php
Remove-Item Env:SALES_PACKAGE_VERIFY_BUNDLE
python scripts/department-sales-release/verify_package.py
php scripts/department-sales-release/verify-runtime.php
```

Tooling pengujian tidak ikut dikirim ke web root. Checksum ZIP berada di file `.zip.sha256` di sebelah arsip; checksum internal ada di `SHA256SUMS.txt`.

## Batas bukti

- Belum diimpor melalui phpMyAdmin server tujuan atau diuji di MariaDB. Versi, izin routine, schema, baseline file bersama, OPcache, cache, dan sesi HR server harus diperiksa saat deployment.
- Pengujian menggunakan fixture sintetis dengan foreign key dan unique constraint; bukan salinan data produksi.
- Verifikasi runtime memeriksa overlay route dan kompilasi Blade; bukan bukti login/browser pada hosting. Pemeriksaan desktop/mobile terdahulu memakai fixture fitur, bukan server tujuan.
- Ini paket update untuk aplikasi Fastware ADSI lengkap yang sudah mempunyai HR. Base Controller, model User/authentication, dan modul KM existing tetap menjadi prasyarat aplikasi. Paket tidak menimpa model User atau menginstal KM baru.
- Snapshot SQL disimpan di audit database, berbeda dari snapshot file private yang dibuat command Artisan. Backup phpMyAdmin tetap wajib.
