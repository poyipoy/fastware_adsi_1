# Upload dan SQL melalui hosting

## Sebelum mulai

- Backup database production, source, public/build, bootstrap/cache, dan foto master. Simpan di luar public_html. Catat hasil SHOW GRANTS dan versi PHP/database.
- Gunakan PHP 8.1+ dengan extension dan package aplikasi yang sudah terpasang (Laravel 10, Excel/PhpSpreadsheet, mbstring, fileinfo, PDO MySQL). SQL ini untuk MySQL 8, bukan MariaDB yang belum diuji.
- Hentikan traffic dan semua worker/scheduler yang dapat menulis selama pemasangan. Gunakan fasilitas maintenance hosting; jangan membuat route/web installer publik.
- Pilih database aplikasi yang benar di phpMyAdmin. Database harus memiliki users, migrations, mst_departments, mst_job_positions, user_job_positions. Jangan impor dump lokal penuh.
- Akun SQL harus dapat SELECT, INSERT, CREATE TABLE, ALTER TABLE, INDEX, REFERENCES, CREATE ROUTINE dan EXECUTE dalam database tersebut. Jika CREATE ROUTINE/EXECUTE tidak tersedia, hentikan pemasangan; jangan menghapus guard SQL.
- Semua resolved_production_user_id pada 00_preflight harus terisi. Akun memakai is_active=0 sebagai aktif. Resolusi NPK memakai satu akun aktif; bila duplikat, hanya tepat satu Administrator role_id=1 yang dapat dipilih. Tidak menyalin ID user lokal.
- Assignment departemen aktif sesuai aturan Warehouse harus sudah tersedia. Query ringkasan 00 bukan pengganti pemeriksaan tanggal assignment oleh aplikasi. Jangan menjalankan migration HR atau mengimpor pengguna untuk mengatasi akses.

## Urutan SQL

Import empat file database satu per satu. Hentikan pada error pertama. Tunggu SCHEMA_OK, kemudian MASTER_ACCESS_OK; simpan hasil postcheck.
01 mengulang preflight sebelum membuat sebelas tabel; seluruh tabel harus belum ada. Tabel dibuat tanpa FK terlebih dahulu, kemudian seluruh FK ditambahkan untuk menangani relasi melingkar. Foreign key checks tetap aktif.
02 memeriksa kolom dan tabel kosong, memetakan NPK, mengimpor master dan tiga verifier dalam transaksi, lalu menambah hanya migration Warehouse yang belum tercatat. Tidak menghapus ledger lama. Tabel kartu legacy dibiarkan kosong.
MySQL DDL melakukan implicit commit: kegagalan 01 dapat meninggalkan schema parsial. Jangan mengulang import atau menggunakan opsi continue/force. Catat error dan minta pemeriksaan schema; restore backup saat belum dibuka untuk transaksi merupakan jalan pemulihan yang aman.
Dua procedure bernama warehouse_release_20261022_schema dan warehouse_release_20261022_master tetap ada untuk bukti instalasi; jangan menambahkan routine tersebut ke menu aplikasi. Tidak ada DROP di SQL kiriman.

## Upload sesuai root Laravel

- Paket berisi folder root asli: app/, bootstrap/, config/, database/, public/, resources/, routes/. Salin file menurut path yang sama. docs/, README.md, INVENTORY.md dan manifest adalah bahan deploy; jangan diterbitkan sebagai halaman publik.
- File bootstrap/app.php sudah memuat bootstrap/warehouse-autoload.php. app/Http/Kernel.php sudah memuat alias middleware; AuthServiceProvider sudah memuat gates; RouteServiceProvider sudah memuat limiter; routes/web.php sudah memuat route auth Warehouse; resources/views/layout.blade.php sudah memuat menu Warehouse. Tidak ada snippet yang perlu ditempel.
- File bersama merupakan versi penuh dari baseline commit yang dicatat di source-manifest.json. Routes dan layout mengikuti commit tersebut dengan blok Warehouse terbaru; perubahan lokal HR dan Outstanding Material yang belum di-commit dikeluarkan dari paket. Bandingkan file bersama production dengan baseline sebelum menggantinya agar perubahan khusus server tetap terjaga. Jika berbeda, rekonsiliasikan hanya perubahan Warehouse terlebih dahulu.
- Model organisasi yang diperlukan tersedia di app/Models/ sesuai path asli. Baseline harus mendukung UserJobPosition::activeAt()/jobPosition() dan MstJobPosition::department(); jika effective_from tersedia, effective_until juga harus ada. Paket tidak mengimpor data atau migration HR.
- Jangan menimpa .env atau vendor. File yang tidak ada dalam paket tetap memakai versi production.
- Upload seluruh public/build beserta manifest.json secara bersamaan ke public aplikasi yang sebenarnya. Pertahankan aset production lama sampai smoke selesai. Paket membawa hasil build global agar manifest dan dependency cocok; sumber modul lain tidak perlu di-upload.
- Pastikan public/hot tidak terbawa/tersisa pada production; file itu mengarahkan Vite ke development server.
- Loader bootstrap yang sudah terpasang memakai require_once untuk enam file konsolidasi. Vendor dan Composer server tidak diganti.
- Composer production harus tetap menyediakan PSR-4 App ke app/. Periksa vendor/composer/autoload_real.php melalui File Manager: jika ada setClassMapAuthoritative(true), hentikan dan gunakan fasilitas autoload hosting. Untuk preload/opcache yang mengunci class lama gunakan reload PHP hosting. Loader enam file tidak mengganti seluruh Composer.
- Tidak perlu mengganti composer.json. vite.config.js disertakan di root untuk build berikutnya; hasil build siap upload sudah tersedia di public/build/.
- Migration asli tersedia di database/migrations/. Setelah import SQL, ledger sudah mencatat 23 migration Warehouse; jangan menjalankan migrate umum atau rollback sebagai bagian pemasangan ini.
- Pastikan shell production memuat Bootstrap JS/CSS, Bootstrap Icons, dan assets/vendor/chart.js/chart.umd.js sebelum stack scripts. Grafik Warehouse memakai window.Chart dari file tersebut; tanpa Chart tabel fallback tetap ada. Gunakan versi aset shell yang sudah dipakai production, jangan mengganti library global secara sepihak.

## Cache tanpa terminal

Saat maintenance masih aktif, backup lalu hapus hanya file cache yang ada melalui File Manager: bootstrap/cache/config.php, bootstrap/cache/routes-v7.php (atau routes-*.php versi hosting), bootstrap/cache/events.php, dan file hasil kompilasi *.php dalam storage/framework/views. Pertahankan .gitignore, direktori, services.php, packages.php, session, dan data aplikasi. Laravel akan membaca konfigurasi/routes baru dan mengompilasi view kembali.
Jika opcache.validate_timestamps dimatikan, lakukan restart/reload PHP lewat panel hosting sebelum smoke. Jangan membuat endpoint optimize:clear atau phpinfo publik.

## Foto dan penutupan

Saat ekspor ini semua photo_path master NULL, sehingga tidak ada foto yang perlu dipindahkan. Untuk unggahan berikutnya disk public harus writable dan public/storage harus terhubung ke storage/app/public. Gunakan fasilitas symlink hosting; jangan mengubah semua storage menjadi direktori publik.
Jalankan SMOKE-CHECKLIST.md, simpan hasil postcheck, lalu buka kembali traffic/worker. SQL production dan smoke production harus dilakukan operator; hasil rehearsal lokal bukan bukti production.
