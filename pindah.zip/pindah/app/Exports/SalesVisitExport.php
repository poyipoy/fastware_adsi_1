<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Carbon\Carbon;

class SalesVisitExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $data;
    protected $startDate;
    protected $endDate;
    protected $salesFilter;
    protected $regionFilter;
    protected $companyFilter;
    protected $userName;

    public function __construct($data, $startDate, $endDate, $salesFilter, $regionFilter, $companyFilter, $userName)
    {
        $this->data = collect($data);
        $this->startDate = $startDate;
        $this->endDate = $endDate;
        $this->salesFilter = $salesFilter;
        $this->regionFilter = $regionFilter;
        $this->companyFilter = $companyFilter;
        $this->userName = $userName;
    }

    public function collection()
    {
        return $this->data;
    }

    public function headings(): array
    {
        return [
            'Nama Sales', 'Tgl Plan', 'Keterangan', 'Nama Customer', 'PIC', 'Tgl Visit', 'Remark', 'Visit Result', 'Files'
        ];
    }

    public function map($row): array
    {
        $files = '-';
        if (is_array($row['files'])) {
            $files = implode(', ', $row['files']);
        } elseif (is_string($row['files'])) {
            $files = $row['files'];
        }

        return [
            $row['sales_name'],
            $row['plan_date'],
            $row['keterangan'],
            $row['company'],
            $row['pic_cust'],
            $row['visit_date'],
            $row['remark'],
            $row['visit_result'],
            $files,
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true], 'fill' => ['fillType' => 'solid', 'startColor' => ['rgb' => 'E0E0E0']]],
        ];
    }
}
