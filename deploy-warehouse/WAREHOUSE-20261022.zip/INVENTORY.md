# Inventori paket

Struktur mengikuti root Laravel. File bersama berisi integrasi lengkap Warehouse; periksa kecocokan baseline production sebelum menggantinya.

## app — 54 file

```text
app/Data/Warehouse/WarehouseDashboardFilter.php
app/Data/Warehouse/WarehouseStockData.php
app/Enums/Warehouse/WarehouseEnums.php
app/Exceptions/WarehouseDomainException.php
app/Exports/WarehouseTransactionsExport.php
app/Http/Controllers/Warehouse/WarehouseCatalogController.php
app/Http/Controllers/Warehouse/WarehouseCategoryController.php
app/Http/Controllers/Warehouse/WarehouseConsumableController.php
app/Http/Controllers/Warehouse/WarehouseDashboardController.php
app/Http/Controllers/Warehouse/WarehouseExportController.php
app/Http/Controllers/Warehouse/WarehouseReportController.php
app/Http/Controllers/Warehouse/WarehouseScanController.php
app/Http/Controllers/Warehouse/WarehouseStockAdjustmentController.php
app/Http/Controllers/Warehouse/WarehouseStockInController.php
app/Http/Controllers/Warehouse/WarehouseStockValidationController.php
app/Http/Controllers/Warehouse/WarehouseTransactionController.php
app/Http/Controllers/Warehouse/WarehouseTransactionHistoryController.php
app/Http/Kernel.php
app/Http/Middleware/EnsureWarehousePermission.php
app/Http/Requests/Warehouse/ConsumableRequests.php
app/Http/Requests/Warehouse/ScanRequests.php
app/Http/Requests/Warehouse/StoreWarehouseAdjustmentRequest.php
app/Http/Requests/Warehouse/StoreWarehouseCategoryRequest.php
app/Http/Requests/Warehouse/TransactionRequests.php
app/Http/Requests/Warehouse/UpdateWarehouseStockAttentionRequest.php
app/Http/Requests/Warehouse/WarehouseAdjustmentHistoryRequest.php
app/Http/Requests/Warehouse/WarehouseDashboardFilterRequest.php
app/Http/Requests/Warehouse/WarehouseReportRequest.php
app/Http/Requests/Warehouse/WarehouseTransactionExportRequest.php
app/Http/Requests/Warehouse/WarehouseTransactionHistoryRequest.php
app/Models/MstDepartment.php
app/Models/MstJobPosition.php
app/Models/UserJobPosition.php
app/Models/Warehouse/WarehouseConsumable.php
app/Models/Warehouse/WarehouseConsumableCategory.php
app/Models/Warehouse/WarehouseLocationShipment.php
app/Models/Warehouse/WarehouseRestrictedVerifier.php
app/Models/Warehouse/WarehouseStockIn.php
app/Models/Warehouse/WarehouseStockTransaction.php
app/Models/Warehouse/WarehouseStockTransactionMachineUsage.php
app/Models/Warehouse/WarehouseVerificationLog.php
app/Providers/AuthServiceProvider.php
app/Providers/RouteServiceProvider.php
app/Services/Warehouse/WarehouseAccessService.php
app/Services/Warehouse/WarehouseDashboardService.php
app/Services/Warehouse/WarehouseIdentityResolver.php
app/Services/Warehouse/WarehouseQuantity.php
app/Services/Warehouse/WarehouseReportService.php
app/Services/Warehouse/WarehouseStockInNumberGenerator.php
app/Services/Warehouse/WarehouseStockInService.php
app/Services/Warehouse/WarehouseStockReservationService.php
app/Services/Warehouse/WarehouseStockService.php
app/Services/Warehouse/WarehouseTransactionQueryService.php
app/Services/Warehouse/WarehouseVerifierPolicy.php
```

## bootstrap — 2 file

```text
bootstrap/app.php
bootstrap/warehouse-autoload.php
```

## config — 1 file

```text
config/warehouse.php
```

## database — 29 file

```text
database/00_preflight.sql
database/01_schema.sql
database/02_master_access.sql
database/03_postcheck.sql
database/master-preview.json
database/migrations/2026_08_07_000001_create_mst_wh_consumable_categories_table.php
database/migrations/2026_08_07_000002_create_mst_wh_consumables_table.php
database/migrations/2026_08_07_000003_create_mst_wh_user_cards_table.php
database/migrations/2026_08_07_000004_create_trs_wh_stock_transactions_table.php
database/migrations/2026_08_07_000005_create_log_wh_verifications_table.php
database/migrations/2026_08_11_000001_add_verification_permissions_to_mst_wh_user_cards_table.php
database/migrations/2026_08_18_000001_add_revision_two_inventory_fields_to_mst_wh_consumables_table.php
database/migrations/2026_08_18_000002_add_revision_two_audit_fields_to_trs_wh_stock_transactions_table.php
database/migrations/2026_08_18_000003_create_mst_wh_restricted_verifiers_table.php
database/migrations/2026_08_18_000004_seed_mst_wh_restricted_verifiers.php
database/migrations/2026_08_19_000001_create_trs_wh_location_shipments_table.php
database/migrations/2026_08_19_000002_add_location_shipment_id_to_trs_wh_stock_transactions_table.php
database/migrations/2026_08_19_000003_drop_storage_location_from_mst_wh_consumables_table.php
database/migrations/2026_08_20_000001_create_trs_wh_stock_ins_table.php
database/migrations/2026_08_26_000001_add_stock_attention_note_to_mst_wh_consumables_table.php
database/migrations/2026_08_26_000002_create_wh_transaction_sequences_table.php
database/migrations/2026_08_26_000003_convert_legacy_location_shipments_to_stock_ins.php
database/migrations/2026_08_27_155918_add_machine_type_used_to_trs_wh_stock_transactions_table.php
database/migrations/2026_09_24_000001_create_wh_stock_in_sequences_table.php
database/migrations/2026_10_06_000001_add_yusuf_to_mst_wh_restricted_verifiers.php
database/migrations/2026_10_06_000002_create_trs_wh_stock_transaction_machine_usages_table.php
database/migrations/2026_10_06_000003_drop_machine_type_from_mst_wh_consumables_table.php
database/migrations/2026_10_06_000004_migrate_legacy_stock_out_machine_usages.php
database/schema-manifest.json
```

## public — 22 file

```text
public/build/assets/app-Bj43h_rG.js
public/build/assets/app-l0sNRNKZ.js
public/build/assets/approval-BURWioDH.js
public/build/assets/authoring-BGW9iQTN.css
public/build/assets/authoring-q3PUHt1c.js
public/build/assets/dashboard-BesOW8eZ.css
public/build/assets/dashboard-BlvCfe1T.js
public/build/assets/dashboard-CagUQXfT.js
public/build/assets/dashboard-G4lfAmCv.css
public/build/assets/foundation-DsupNLJs.css
public/build/assets/foundation-GLnNL16_.css
public/build/assets/management-L5qeiG7U.css
public/build/assets/pdf.worker.min-CNLDpoK4.js
public/build/assets/pdfjs-BdaRZebo.js
public/build/assets/reporting-dSontHnq.css
public/build/assets/shell-Ca5ZZWlx.js
public/build/assets/stock-in-BHIj9sEr.css
public/build/assets/stock-in-DCpsY67O.js
public/build/assets/transaction-form-Cp5vMBS5.js
public/build/assets/transaction-form-DKHV1U3c.css
public/build/assets/ui-feedback-BObBBXdP.js
public/build/manifest.json
```

## resources — 31 file

```text
resources/css/warehouse/dashboard.css
resources/css/warehouse/foundation.css
resources/css/warehouse/management.css
resources/css/warehouse/reporting.css
resources/css/warehouse/stock-in.css
resources/css/warehouse/transaction-form.css
resources/js/warehouse/dashboard.js
resources/js/warehouse/stock-in.js
resources/js/warehouse/transaction-form.js
resources/views/components/warehouse/empty-state.blade.php
resources/views/components/warehouse/filter-actions.blade.php
resources/views/components/warehouse/page-header.blade.php
resources/views/components/warehouse/panel.blade.php
resources/views/components/warehouse/status-badge.blade.php
resources/views/layout.blade.php
resources/views/vendor/pagination/warehouse-bootstrap-5.blade.php
resources/views/warehouse/adjustments-create.blade.php
resources/views/warehouse/categories.blade.php
resources/views/warehouse/consumables/form.blade.php
resources/views/warehouse/consumables/index.blade.php
resources/views/warehouse/consumables/show.blade.php
resources/views/warehouse/dashboard/index.blade.php
resources/views/warehouse/layout.blade.php
resources/views/warehouse/reports/index.blade.php
resources/views/warehouse/stock-in/show.blade.php
resources/views/warehouse/stock-in/validate.blade.php
resources/views/warehouse/transactions/create.blade.php
resources/views/warehouse/transactions/index.blade.php
resources/views/warehouse/transactions/reverse.blade.php
resources/views/warehouse/transactions/show.blade.php
resources/views/warehouse/validations/index.blade.php
```

## routes — 1 file

```text
routes/web.php
```

## docs — 11 file

```text
docs/CONTEXT.md
docs/DEPLOY.md
docs/LOCAL-RESET-RESULT.json
docs/MIGRATION-REHEARSAL-RESULT.json
docs/PACKAGE-VERIFICATION.json
docs/ROLLBACK.md
docs/SHELL-CONTRACT.md
docs/SMOKE-CHECKLIST.md
docs/SQL-REHEARSAL-RESULT.json
docs/VALIDATION.md
docs/WAREHOUSE-TEST-RESULT.json
```
