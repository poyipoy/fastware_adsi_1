# Laravel FCM Notification Flow - Dokumentasi untuk Android Developer

## Status Backend: ✅ BERHASIL

Log server menunjukkan notifikasi **sudah berhasil terkirim** dari Laravel:
```
[2026-01-15 16:47:38] local.INFO: FCM (HTTP v1) sent successfully to: eXl7AbP4Qoe5sRD...
[2026-01-15 16:47:38] local.INFO: Notif sent to DeptHead: ILHAM CHOLID
```

---

## Alur Notifikasi dari Laravel

### 1. Trigger: Sales Submit Kunjungan
**Endpoint:** `POST /api/sales-visit`  
**Controller:** `SalesVisitController@store`

### 2. Logic Penentuan Penerima
```
Sender: SARAH EGA BUDI ASTUTI
↓
Cari di Mapping: siapa Dept Head dari Sarah?
↓
Found: ILHAM CHOLID
↓
Ambil fcm_token dari tabel users WHERE name = 'ILHAM CHOLID'
```

### 3. Payload Notifikasi yang Dikirim
```json
{
  "notification": {
    "title": "Kunjungan Baru",
    "body": "Sales SARAH EGA BUDI ASTUTI baru saja submit kunjungan ke [nama customer]"
  },
  "data": {
    "type": "visit",
    "visit_id": "123"
  }
}
```

---

## Masalah di Android

Notifikasi **tidak muncul** meskipun server berhasil mengirim. Kemungkinan penyebab:

### 1. App dalam Foreground
Ketika app **sedang dibuka**, Android **tidak otomatis menampilkan** notifikasi.  
Android developer harus handle di `FirebaseMessagingService`:

```kotlin
// MyFirebaseMessagingService.kt
override fun onMessageReceived(remoteMessage: RemoteMessage) {
    // CEK apakah ada data notification
    remoteMessage.notification?.let { notification ->
        // Tampilkan notifikasi secara manual
        showNotification(notification.title, notification.body)
    }
}

private fun showNotification(title: String?, body: String?) {
    val channelId = "visit_channel"
    val notificationBuilder = NotificationCompat.Builder(this, channelId)
        .setSmallIcon(R.drawable.ic_notification)
        .setContentTitle(title)
        .setContentText(body)
        .setAutoCancel(true)
        .setPriority(NotificationCompat.PRIORITY_HIGH)

    val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // Buat channel untuk Android O+
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(
            channelId,
            "Visit Notifications",
            NotificationManager.IMPORTANCE_HIGH
        )
        notificationManager.createNotificationChannel(channel)
    }

    notificationManager.notify(System.currentTimeMillis().toInt(), notificationBuilder.build())
}
```

### 2. Notification Channel Belum Dibuat
Untuk Android 8.0+, wajib ada **Notification Channel**. Pastikan sudah dibuat di `Application` class atau saat app start.

### 3. Permission POST_NOTIFICATIONS (Android 13+)
Untuk Android 13 ke atas, user harus memberikan izin notifikasi:

```kotlin
// Di Activity utama
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
    if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) 
        != PackageManager.PERMISSION_GRANTED) {
        ActivityCompat.requestPermissions(this, 
            arrayOf(Manifest.permission.POST_NOTIFICATIONS), 
            NOTIFICATION_PERMISSION_CODE)
    }
}
```

Dan di `AndroidManifest.xml`:
```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
```

### 4. Token FCM Berubah
Token FCM bisa berubah kapan saja. Pastikan di `onNewToken()` selalu update ke server:

```kotlin
override fun onNewToken(token: String) {
    // Kirim token baru ke server
    sendTokenToServer(token)
}
```

---

## Endpoint untuk Update Token

**Endpoint:** `POST /api/user/fcm-token`  
**Auth:** Bearer Token (Sanctum)  
**Body:**
```json
{
  "fcm_token": "eXl7AbP4Qoe5sRD_IyGTTJ:APA91bHWbVy93mXcjiltrNzO1..."
}
```

---

## Checklist untuk Android Developer

- [ ] Pastikan `FirebaseMessagingService` sudah diregister di `AndroidManifest.xml`
- [ ] Handle `onMessageReceived()` untuk tampilkan notifikasi saat app foreground
- [ ] Buat Notification Channel untuk Android 8.0+
- [ ] Minta permission `POST_NOTIFICATIONS` untuk Android 13+
- [ ] Update token ke server setiap kali `onNewToken()` dipanggil
- [ ] Test dengan app di background (minimize) - seharusnya muncul

---

## Testing

1. **App di Background**: Close app, kirim notifikasi → harusnya muncul di status bar
2. **App di Foreground**: Buka app, kirim notifikasi → handle manual di `onMessageReceived()`
