# Update Master Department dan Sales Region 1-4

Paket ini untuk project Fastware ADSI Laravel 10 yang **sudah memiliki modul HR/TCPD**. Isi folder rilis/ZIP langsung mengikuti root Laravel. Tidak ada wrapper `runtime/` atau instalasi ulang HR.

**Pilihan default: impor hanya `database/sql/sales-region-split/split_sales_regions_only.sql`.** File ini mandiri: validasi, split, audit, pemeriksaan hasil, dan cleanup helper berada di dalamnya. Jangan menjalankan file `00–03` bersamaan dengan jalur standalone.

## Sebelum copy

1. Batasi akses aplikasi melalui fasilitas maintenance hosting, terutama perubahan organisasi, assignment, approval KM, dan penilaian. Jangan izinkan dua operator mengimpor SQL bersamaan.
2. Di phpMyAdmin pilih database tujuan, lalu **Export → Custom** dan unduh backup SQL lengkap (struktur + data). Simpan juga salinan file server yang akan ditimpa berdasarkan `manifest-files.txt`. Jangan gunakan snapshot database lokal pengembang sebagai data server.
3. SQL standalone memerlukan InnoDB, JSON, MySQL 8+ atau MariaDB 10.5+, serta izin `SELECT`, `INSERT`, `UPDATE`, `CREATE TEMPORARY TABLES`, `CREATE ROUTINE`, `ALTER ROUTINE`, dan `EXECUTE`. Tidak memerlukan pembuatan tabel aplikasi. Eksekusi langsung sudah diuji pada MySQL 8.0.30. MariaDB dan hak hosting tujuan belum diverifikasi; uji pada salinan database server sebelum impor produksi.
4. Database HR harus sudah memiliki tabel audit `km_organization_assignment_audits`, kolom assignment `effective_from`, `effective_until`, `assignment_source`, foreign key, dan unique constraint existing. Standalone memeriksa semuanya dan **berhenti sebelum menulis data** jika belum lengkap. Jangan menjalankan file 01 untuk melewati kegagalan ini; penyiapan prasyarat merupakan pekerjaan terpisah.
5. Model User/authentication dan base Controller tetap menggunakan versi server. Modul KM existing diperlukan jika fitur KM digunakan. Paket tidak menambahkan provider, dependency Composer, atau menandai seluruh migrasi KM sebagai sudah dijalankan.

## Urutan pemasangan melalui File Manager/FTP + phpMyAdmin

1. Pilih database HR tujuan di phpMyAdmin dan pastikan backup sudah tersimpan. Jangan memilih database lokal pengembang yang sudah selesai dipisahkan.
2. Salin folder **`app/`, `public/`, `resources/`, `routes/`** dari paket ke root project Laravel server dengan mempertahankan path masing-masing. Folder `database/sql/` dan `docs/` boleh disimpan pada root project untuk operator; bukan di dalam `public/`.
3. File bersama `routes/web.php` dan `resources/views/layout.blade.php` berupa file lengkap. Paket memakai baseline checkout pengembangan saat rilis; tujuh rute arsip Outstanding Material dari pekerjaan terpisah sengaja dikeluarkan. Jika server memiliki perubahan mandiri pada kedua file ini, bandingkan dan gabungkan perubahan HR dahulu agar rute/menu server tidak tertimpa.
4. Impor **`database/sql/sales-region-split/split_sales_regions_only.sql` saja**. Tidak ada `USE`, ID master/user lokal, `CREATE/ALTER/DROP TABLE` aplikasi, `TRUNCATE`, penonaktifan FK, atau penghapusan data HR. Helper routine dan tabel temporary dipakai untuk validasi/locking/transaksi.
5. Eksekusi pertama menampilkan `READY`, kemudian `APPLIED` dan hasil pemeriksaan. Actor dicari secara unik berdasarkan nama persis **SITI MARIA ULFA**, bukan ID 91. Pejabat kepala diambil dari assignment kepala gabungan **di server tersebut**, bukan dari nama/ID pejabat lokal. `COMPLETED_NOOP` berarti jurnal sudah ada dan data tidak dipisahkan ulang.
6. Periksa hasil yang langsung ditampilkan SQL. Setelah sukses, kedua helper routine standalone dibersihkan. Jika ada error, berhenti; jangan menganggap hasil query lain sebagai keberhasilan. Perubahan data cutover di-rollback. Jika phpMyAdmin berhenti pada error, helper dapat tersisa; impor ulang file standalone akan menggantinya. Pembersihan manual, jika diperlukan, hanya untuk `sales_dept_20261026_only_apply` dan `sales_dept_20261026_only_validate`.
7. Bersihkan route cache dan Blade cache melalui fasilitas terminal/panel hosting. Jika tidak tersedia terminal, hapus **file cache hasil generate saja** melalui File Manager: `bootstrap/cache/routes-*.php` dan `storage/framework/views/*.php` (atau direktori compiled view yang dikonfigurasi hosting). Pertahankan direktori, `.gitignore`, dan file cache/config lainnya. Jangan hapus session atau `.env`.
8. Jika OPcache tidak mendeteksi perubahan file, gunakan fasilitas restart PHP/OPcache pada panel hosting. Tidak perlu dependency baru, `npm install`, atau Vite build; stylesheet dan JavaScript HR pada paket berupa asset statis. Autoload normal PSR-4 harus aktif; hosting yang memakai Composer classmap-authoritative harus membangun ulang autoload melalui fasilitas deploymentnya.
9. Login sebagai pengelola HR, verifikasi fitur, kemudian buka kembali akses aplikasi.

## Hasil yang diharapkan

- Empat department aktif: Sales Region 1, 2, 3, dan 4, masing-masing dengan satu job kepala `dept_head` baru.
- Pejabat dari kepala lama 1&2 memegang kepala Region **1 dan 3**. Pejabat dari kepala lama 3&4 memegang kepala Region **2 dan 4**. HR dapat menggantinya kemudian melalui Mapping Karyawan.
- Section serta seluruh posisinya, termasuk yang nonaktif, berpindah sesuai region. Incoming approval kepala lama dialihkan menurut section posisi bawahan; termasuk level 1 dan 2 untuk Region 3/4. Kepala baru memiliki approval level 3 ke Sales Div Head. Approval lain dipertahankan.
- Dua department/job gabungan dan assignment lamanya nonaktif. Assignment baru efektif pada tanggal impor menurut Asia/Jakarta; assignment lama berakhir sehari sebelumnya.
- Seluruh indikator `violations` hasil standalone bernilai **0**, jumlah department/job kepala baru **4**, dan standar kompetensi kepala baru **0**. Isi TC/SK/Additional melalui HR sebelum penilaian job baru.
- Training, assessment, standar lama, Working Experience, dan assignment yang tidak terkait dipertahankan. Tidak ada salinan penilaian/standar ke job baru.
- Master Department tampil di HR → Base Competency untuk pengelola yang berwenang. Periksa tambah/edit/status, detail section, dan akses masing-masing pejabat. Jangan membuat perubahan uji pada data produksi hanya untuk smoke test.

## Audit, pengulangan, dan koreksi

SQL menyimpan snapshot baris organisasi yang disentuh pada `before_state` jurnal `km_organization_assignment_audits` dengan action `sales_region_split_completed`. Audit per assignment juga tersimpan. Isi audit dapat memuat referensi karyawan; perlakukan sebagai data privat. SQL tidak dapat menulis backup file server; backup phpMyAdmin tetap wajib.

Jika standalone diimpor ulang, jurnal yang valid menghasilkan `COMPLETED_NOOP` dan tidak mengembalikan perubahan HR setelah cutover. Jangan menghapus jurnal untuk memaksa eksekusi ulang.

Tidak ada rollback otomatis setelah commit. Untuk koreksi, hentikan aktivitas, periksa backup dan snapshot audit, serta perhitungkan perubahan HR/ transaksi sesudah impor. Jangan mengembalikan database penuh secara otomatis karena dapat menimpa transaksi sah.

## Alternatif lama 00–03, bukan untuk dijalankan bersamaan

Empat file lama tetap disertakan sebagai jalur alternatif: `00_preflight.sql` → `01_prerequisites.sql` → `02_split_sales_regions.sql` → `03_postcheck.sql`. Jalur ini memiliki kemampuan tambahan membuat tabel audit jika belum ada, sehingga memerlukan izin `CREATE` dan `REFERENCES` serta persetujuan penyiapan schema tersendiri. **Untuk kebutuhan split data saja, gunakan standalone dan jangan menjalankan jalur alternatif ini.** File 02 lama tidak mandiri.

## Batas paket

Paket tidak mengirim `.env`, vendor, node_modules, cache, workbook, snapshot privat, compiled Vite assets, atau perubahan Warehouse/Outstanding Material. File HR bersama menyertakan dependensi izin baca mapping/riwayat dan assessment-summary yang diperlukan oleh snapshot kode ini. Ini bukan paket instalasi HR/KM baru.
