<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\LogbookVisits;
use App\Models\TrsLogbookVisits;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\SalesVisitExport;
use Carbon\Carbon;

class SalesVisitController extends Controller
{
    /**
     * Display the sales visit dashboard
     */
    public function index()
    {
        // Check authorization
        if (!$this->isAuthorizedUser()) {
            abort(403, 'Unauthorized access');
        }

        return view('dashboard.dashboardSalesVisit');
    }

    /**
     * Get dashboard data via AJAX
     */
    public function getDashboardData(Request $request)
    {
        // Check authorization
        if (!$this->isAuthorizedUser()) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $user = Auth::user();
        $isAdmin = $this->isAdmin($user);

        // Get date filters (default: last 7 days)
        $endDate = $request->input('endDate', Carbon::now()->format('Y-m-d'));
        $startDate = $request->input('startDate', Carbon::now()->subDays(7)->format('Y-m-d'));
        
        $salesFilter = trim($request->input('salesFilter'));
        $regionFilter = trim($request->input('regionFilter'));
        $companyFilter = trim($request->input('companyFilter'));

        // Get sales team based on user role
        $salesUserIds = $this->getSalesUserIds($user, $isAdmin);

        // Query visits (filtered by date)
        $visitsQuery = LogbookVisits::with('user')
            ->when(!$isAdmin && !empty($salesUserIds), fn($q) => $q->whereIn('id_user', $salesUserIds))
            ->when($startDate, fn($q) => $q->whereDate('visit_date', '>=', $startDate))
            ->when($endDate, fn($q) => $q->whereDate('visit_date', '<=', $endDate))
            ->when($salesFilter, fn($q) => $q->whereHas('user', fn($u) => $u->where('name', $salesFilter)))
            ->when($regionFilter, function($q) use ($regionFilter) {
                $regionMappings = $this->getRegionMappings();
                $salesInRegion = $regionMappings[$regionFilter] ?? [];
                return $q->whereHas('user', fn($u) => $u->whereIn('name', $salesInRegion));
            })
            ->when($companyFilter, fn($q) => $q->where('customer_name', 'LIKE', "%{$companyFilter}%"));

        $visits = $visitsQuery->get();

        // Query plans (filtered by date)
        $plansQuery = TrsLogbookVisits::with('user')
            ->when(!$isAdmin && !empty($salesUserIds), fn($q) => $q->whereIn('id_user', $salesUserIds))
            ->when($startDate, fn($q) => $q->whereDate('plan_visit', '>=', $startDate))
            ->when($endDate, fn($q) => $q->whereDate('plan_visit', '<=', $endDate))
            ->when($salesFilter, fn($q) => $q->whereHas('user', fn($u) => $u->where('name', $salesFilter)))
            ->when($regionFilter, function($q) use ($regionFilter) {
                $regionMappings = $this->getRegionMappings();
                $salesInRegion = $regionMappings[$regionFilter] ?? [];
                return $q->whereHas('user', fn($u) => $u->whereIn('name', $salesInRegion));
            })
            ->when($companyFilter, fn($q) => $q->where('customer_name', 'LIKE', "%{$companyFilter}%"));

        $plans = $plansQuery->get();

        // Calculate summary using STRICT data
        $strictComparison = $this->compareVisitsAndPlans($visits, $plans);
        $summary = $this->calculateSummary($strictComparison, $visits);

        // Get chart data (Use collections to avoid re-querying)
        $chartData = $this->getChartData($user, $isAdmin, $startDate, $endDate, $salesFilter, $regionFilter, $companyFilter, $visits, $plans);

        // Get company list
        $companies = $this->getCompanyList();

        return response()->json([
            'summary' => $summary,
            'comparisonData' => [],
            'chartData' => $chartData,
            'companies' => $companies,
        ]);
    }

    /**
     * Get DataTables Server-side Data
     */
    public function getDetailData(Request $request)
    {
        $startDate = $request->input('startDate');
        $endDate = $request->input('endDate');
        $salesFilter = trim($request->input('salesFilter'));
        $regionFilter = trim($request->input('regionFilter'));
        $companyFilter = trim($request->input('companyFilter'));

        // Get Full Comparison Data (Expanded)
        $data = $this->getExpandedData($startDate, $endDate, $salesFilter, $regionFilter, $companyFilter);

        // --- Server-side Processing (Manual) ---
        $totalData = count($data);
        $totalFiltered = $totalData;

        // 1. Searching
        $searchValue = $request->input('search.value');
        if ($searchValue) {
            $data = array_filter($data, function ($row) use ($searchValue) {
                // Search in all visible columns
                foreach ($row as $value) {
                    if (is_array($value)) continue; // Skip files array
                    if (stripos((string)$value, $searchValue) !== false) {
                        return true;
                    }
                }
                return false;
            });
            $totalFiltered = count($data);
        }

        // 2. Sorting
        $orderColumnIndex = $request->input('order.0.column');
        $orderDir = $request->input('order.0.dir', 'asc');
        
        // Map DataTable column index to Array keys
        $columnMap = [
            0 => 'sales_name',
            1 => 'plan_date',
            2 => 'keterangan',
            3 => 'company',
            4 => 'pic_cust',
            5 => 'visit_date',
            6 => 'remark',
            7 => 'visit_result'
        ];

        if (isset($columnMap[$orderColumnIndex])) {
            $sortKey = $columnMap[$orderColumnIndex];
            usort($data, function ($a, $b) use ($sortKey, $orderDir) {
                $valA = $a[$sortKey] ?? '';
                $valB = $b[$sortKey] ?? '';
                if ($valA == $valB) return 0;
                return ($orderDir === 'asc') ? ($valA <=> $valB) : ($valB <=> $valA);
            });
        }

        // 3. Pagination
        $start = $request->input('start', 0);
        $length = $request->input('length', 10);
        
        // Handle length = -1 (All records)
        if ($length == -1) {
            $length = $totalFiltered;
        }

        $data = array_slice($data, $start, $length);

        return response()->json([
            'draw' => intval($request->input('draw')),
            'recordsTotal' => $totalData,
            'recordsFiltered' => $totalFiltered,
            'data' => array_values($data)
        ]);
    }

    /**
     * Get Expanded Data for Table/Export
     */
    private function getExpandedData($startDate, $endDate, $salesFilter, $regionFilter, $companyFilter)
    {
        $user = Auth::user();
        $isAdmin = $this->isAdmin($user);
        $salesUserIds = $this->getSalesUserIds($user, $isAdmin);

        // 1. Initial Strict Filter (to find involved customers)
        $visitsQuery = LogbookVisits::with('user')
            ->when(!$isAdmin && !empty($salesUserIds), fn($q) => $q->whereIn('id_user', $salesUserIds))
            ->when($startDate, fn($q) => $q->whereDate('visit_date', '>=', $startDate))
            ->when($endDate, fn($q) => $q->whereDate('visit_date', '<=', $endDate))
            ->when($salesFilter, fn($q) => $q->whereHas('user', fn($u) => $u->where('name', $salesFilter)))
            ->when($regionFilter, function($q) use ($regionFilter) {
                $regionMappings = $this->getRegionMappings();
                $salesInRegion = $regionMappings[$regionFilter] ?? [];
                return $q->whereHas('user', fn($u) => $u->whereIn('name', $salesInRegion));
            })
            ->when($companyFilter, fn($q) => $q->where('customer_name', 'LIKE', "%{$companyFilter}%"));

        $visits = $visitsQuery->get();

        $plansQuery = TrsLogbookVisits::with('user')
            ->when(!$isAdmin && !empty($salesUserIds), fn($q) => $q->whereIn('id_user', $salesUserIds))
            ->when($startDate, fn($q) => $q->whereDate('plan_visit', '>=', $startDate))
            ->when($endDate, fn($q) => $q->whereDate('plan_visit', '<=', $endDate))
            ->when($salesFilter, fn($q) => $q->whereHas('user', fn($u) => $u->where('name', $salesFilter)))
            ->when($regionFilter, function($q) use ($regionFilter) {
                $regionMappings = $this->getRegionMappings();
                $salesInRegion = $regionMappings[$regionFilter] ?? [];
                return $q->whereHas('user', fn($u) => $u->whereIn('name', $salesInRegion));
            })
            ->when($companyFilter, fn($q) => $q->where('customer_name', 'LIKE', "%{$companyFilter}%"));

        $plans = $plansQuery->get();

        // Identify customers involved
        $visitCustomers = $visits->pluck('customer_name')->unique();
        $planCustomers = $plans->pluck('customer_name')->unique();
        $involvedCustomers = $visitCustomers->merge($planCustomers)->unique()->filter()->values();

        // 2. Fetch All History
        if ($involvedCustomers->isNotEmpty()) {
            $allVisits = LogbookVisits::with('user')
                ->whereIn('customer_name', $involvedCustomers)
                ->when(!$isAdmin && !empty($salesUserIds), fn($q) => $q->whereIn('id_user', $salesUserIds))
                ->when($salesFilter, fn($q) => $q->whereHas('user', fn($u) => $u->where('name', $salesFilter)))
                ->when($regionFilter, function($q) use ($regionFilter) {
                    $regionMappings = $this->getRegionMappings();
                    $salesInRegion = $regionMappings[$regionFilter] ?? [];
                    return $q->whereHas('user', fn($u) => $u->whereIn('name', $salesInRegion));
                })
                ->get();

            $allPlans = TrsLogbookVisits::with('user')
                ->whereIn('customer_name', $involvedCustomers)
                ->when(!$isAdmin && !empty($salesUserIds), fn($q) => $q->whereIn('id_user', $salesUserIds))
                ->when($salesFilter, fn($q) => $q->whereHas('user', fn($u) => $u->where('name', $salesFilter)))
                ->when($regionFilter, function($q) use ($regionFilter) {
                    $regionMappings = $this->getRegionMappings();
                    $salesInRegion = $regionMappings[$regionFilter] ?? [];
                    return $q->whereHas('user', fn($u) => $u->whereIn('name', $salesInRegion));
                })
                ->get();
        } else {
            $allVisits = $visits;
            $allPlans = $plans;
        }

        // Compare
        $fullComparisonData = $this->compareVisitsAndPlans($allVisits, $allPlans);

        // Filter final result
        $comparisonData = array_filter($fullComparisonData, function($row) use ($startDate, $endDate) {
            // Normalize dates to Y-m-d for comparison
            $planDate = substr($row['plan_date'], 0, 10);
            $visitDate = substr($row['visit_date'], 0, 10);
            
            $planInRange = ($row['plan_date'] !== '-') && 
                (!$startDate || $planDate >= $startDate) && 
                (!$endDate || $planDate <= $endDate);
                
            $visitInRange = ($row['visit_date'] !== '-') && 
                (!$startDate || $visitDate >= $startDate) && 
                (!$endDate || $visitDate <= $endDate);
                
            return $planInRange || $visitInRange;
        });

        return array_values($comparisonData);
    }

    /**
     * Export dashboard data to Excel
     */
    public function exportExcel(Request $request)
    {
        // Check authorization
        if (!$this->isAuthorizedUser()) {
            abort(403, 'Unauthorized access');
        }

        $user = Auth::user();
        
        // Get filters (Consistent with getDetailData)
        $startDate = $request->input('startDate');
        $endDate = $request->input('endDate');
        $salesFilter = trim($request->input('salesFilter'));
        $regionFilter = trim($request->input('regionFilter'));
        $companyFilter = trim($request->input('companyFilter'));

        // Use helper to get data
        $comparisonData = $this->getExpandedData($startDate, $endDate, $salesFilter, $regionFilter, $companyFilter);

        $fileName = 'Sales_Visit_Report_' . Carbon::now()->format('Y-m-d_His') . '.xlsx';

        return Excel::download(new SalesVisitExport($comparisonData, $startDate, $endDate, $salesFilter, $regionFilter, $companyFilter, $user->name), $fileName);
    }

    /**
     * Get sales user IDs based on role
     */
    private function getSalesUserIds($user, $isAdmin)
    {
        if ($isAdmin) {
            return []; // Admin can see all
        }

        $deptHeadMappings = $this->getDepartmentHeadMappings();
        $userName = strtoupper($user->name);

        if (array_key_exists($userName, $deptHeadMappings)) {
            $salesTeam = $deptHeadMappings[$userName] ?? [];
            return User::whereIn('name', $salesTeam)->pluck('id')->toArray();
        }

        // Regular Sales: Can only see themselves
        return [$user->id];
    }

    /**
     * Compare visits and plans to generate comparison data
     * Logic: 
     * - Process visits first, find matching plan for each visit
     * - Match by customer_name (case-insensitive)
     * - Each plan can only be matched once
     * - Remaining unmatched plans are shown as plan-only rows
     */
    private function compareVisitsAndPlans($visits, $plans)
    {
        $comparisonData = [];
        $matchedPlanIds = [];
        
        // Sort visits by visit_date
        $sortedVisits = $visits->sortBy('visit_date')->values();
        
        // Sort plans by plan_visit date
        $sortedPlans = $plans->sortBy('plan_visit')->values();

        // Process each visit and find matching plan
        foreach ($sortedVisits as $visit) {
            $visitCustomerName = strtolower(trim($visit->customer_name ?? ''));
            
            // Find first unmatched plan for this customer
            $matchingPlan = null;
            foreach ($sortedPlans as $plan) {
                if (in_array($plan->id, $matchedPlanIds)) {
                    continue; // Skip already matched plans
                }
                
                $planCustomerName = strtolower(trim($plan->customer_name ?? ''));
                if ($planCustomerName === $visitCustomerName) {
                    $matchingPlan = $plan;
                    $matchedPlanIds[] = $plan->id;
                    break;
                }
            }

            // Parse file field (JSON array)
            $files = '-';
            if (!empty($visit->file)) {
                $fileData = json_decode($visit->file, true);
                if (is_array($fileData) && count($fileData) > 0) {
                    $files = $fileData;
                } elseif (is_string($visit->file) && !empty($visit->file)) {
                    $files = [$visit->file];
                }
            }

            // Determine display customer name (new_customer_name if exists, else customer_name)
            $displayCustomer = !empty($visit->new_customer_name) 
                ? $visit->new_customer_name 
                : $visit->customer_name;

            $comparisonData[] = [
                'sales_name' => $visit->user->name ?? '-',
                'plan_date' => $matchingPlan?->plan_visit ?? '-',
                'keterangan' => $matchingPlan?->keterangan ?? '-',
                'company' => $displayCustomer ?? '-',
                'pic_cust' => $visit->pic_cust ?? '-',
                'visit_date' => $visit->visit_date ?? '-',
                'remark' => $visit->remark ?? '-',
                'visit_result' => $visit->visit_result ?? '-',
                'files' => $files,
            ];
        }

        // Process plans without visits (Plan Only)
        foreach ($sortedPlans as $plan) {
            if (!in_array($plan->id, $matchedPlanIds)) {
                $comparisonData[] = [
                    'sales_name' => $plan->user->name ?? '-',
                    'plan_date' => $plan->plan_visit ?? '-',
                    'keterangan' => $plan->keterangan ?? '-',
                    'company' => $plan->customer_name ?? '-',
                    'pic_cust' => '-',
                    'visit_date' => '-',
                    'remark' => '-',
                    'visit_result' => '-',
                    'files' => '-',
                ];
            }
        }

        return $comparisonData;
    }

    /**
     * Calculate summary statistics with customer breakdown
     */
    private function calculateSummary($comparisonData, $visits)
    {
        $totalPlans = 0;
        $totalVisits = 0;
        $sesuaiPlan = 0;
        $tidakSesuaiPlan = 0;

        // Collect unique customer names (case-insensitive)
        $uniqueCustomers = [];

        foreach ($comparisonData as $data) {
            $hasPlan = $data['plan_date'] !== '-';
            $hasVisit = $data['visit_date'] !== '-';
            
            if ($hasPlan) {
                $totalPlans++;
            }
            if ($hasVisit) {
                $totalVisits++;
            }
            // Sesuai Plan = has both plan and visit with same date
            if ($hasPlan && $hasVisit && $data['plan_date'] === $data['visit_date']) {
                $sesuaiPlan++;
            }
            // Tidak Sesuai Plan = has both plan and visit but different dates
            if ($hasPlan && $hasVisit && $data['plan_date'] !== $data['visit_date']) {
                $tidakSesuaiPlan++;
            }
            // Collect unique customer names
            if (!empty($data['company'])) {
                $uniqueCustomers[strtolower(trim($data['company']))] = true;
            }
        }

        // Count customer lama and customer baru from visits
        $customerLama = 0;
        $customerBaru = 0;
        $processedCustomers = [];

        foreach ($visits as $visit) {
            $customerKey = strtolower(trim($visit->customer_name ?? ''));
            if (empty($customerKey) || isset($processedCustomers[$customerKey])) {
                continue;
            }
            $processedCustomers[$customerKey] = true;

            if (empty($visit->new_customer_name)) {
                $customerLama++;
            } else {
                $customerBaru++;
            }
        }

        return [
            'totalPlans' => $totalPlans,
            'totalVisits' => $totalVisits,
            'sesuaiPlan' => $sesuaiPlan,
            'tidakSesuaiPlan' => $tidakSesuaiPlan,
            'totalCustomer' => count($uniqueCustomers),
            'customerLama' => $customerLama,
            'customerBaru' => $customerBaru,
        ];
    }

    /**
     * Get chart data for visualization with role-based filtering
     */
    private function getChartData($user, $isAdmin, $startDate, $endDate, $salesFilter, $regionFilter, $companyFilter, $visits = null, $plans = null)
    {
        // Determine allowed sales names based on role
        $allowedSalesNames = [];
        
        if ($isAdmin) {
            // Admin can see all sales from department mappings AND themselves
            $deptMappings = $this->getDepartmentHeadMappings();
            foreach ($deptMappings as $salesList) {
                $allowedSalesNames = array_merge($allowedSalesNames, $salesList);
            }
            // Add Admin names explicitly (so they appear in filters/charts if they have data)
            $adminNames = $this->getAdminNames();
            $allowedSalesNames = array_merge($allowedSalesNames, $adminNames);
            
            $allowedSalesNames = array_unique($allowedSalesNames);
        } else {
            // DeptHead can only see their subordinates
            $deptMappings = $this->getDepartmentHeadMappings();
            $userName = strtoupper($user->name); // Match case with Mappings key
            $allowedSalesNames = $deptMappings[$userName] ?? [$user->name];
            
            // Ensure valid array if mapping missing
            if (empty($allowedSalesNames)) {
                $allowedSalesNames = [$user->name];
            }
        }

        // Apply sales filter if specified
        if ($salesFilter) {
            // Strict comparison
            $allowedSalesNames = array_filter($allowedSalesNames, fn($name) => strcasecmp($name, $salesFilter) === 0);
        }

        // Apply region filter if specified
        if ($regionFilter) {
            $regionMappings = $this->getRegionMappings();
            $salesInRegion = $regionMappings[$regionFilter] ?? [];
            $allowedSalesNames = array_intersect($allowedSalesNames, $salesInRegion);
        }

        // Get users by name (Exact match)
        $salesUsers = User::whereIn('name', $allowedSalesNames)->get();

        $labels = [];
        $visitCounts = [];
        $planCounts = [];
        // ... rest of logic ...

        foreach ($salesUsers as $salesUser) {
            $labels[] = $salesUser->name;

            if ($visits !== null && $plans !== null) {
                // Use provided collections (Consistent & Fast)
                $visitCount = $visits->where('id_user', $salesUser->id)->count();
                $planCount = $plans->where('id_user', $salesUser->id)->count();
            } else {
                // Count visits for this sales
                $visitCount = LogbookVisits::where('id_user', $salesUser->id)
                    ->when($startDate, fn($q) => $q->whereDate('visit_date', '>=', $startDate))
                    ->when($endDate, fn($q) => $q->whereDate('visit_date', '<=', $endDate))
                    ->when($companyFilter, fn($q) => $q->where('customer_name', 'LIKE', "%{$companyFilter}%"))
                    ->count();

                // Count plans for this sales
                $planCount = TrsLogbookVisits::where('id_user', $salesUser->id)
                    ->when($startDate, fn($q) => $q->whereDate('plan_visit', '>=', $startDate))
                    ->when($endDate, fn($q) => $q->whereDate('plan_visit', '<=', $endDate))
                    ->when($companyFilter, fn($q) => $q->where('customer_name', 'LIKE', "%{$companyFilter}%"))
                    ->count();
            }

            $visitCounts[] = $visitCount;
            $planCounts[] = $planCount;
        }

        return [
            'labels' => $labels,
            'visits' => $visitCounts,
            'plans' => $planCounts,
        ];
    }

    /**
     * Get unique company list from both logbook_visits and trs_logbook_visits (case-insensitive)
     */
    private function getCompanyList()
    {
        // Get customer names from logbook_visits
        $visitCustomers = LogbookVisits::whereNotNull('customer_name')
            ->where('customer_name', '!=', '')
            ->pluck('customer_name')
            ->toArray();

        // Get customer names from trs_logbook_visits
        $planCustomers = TrsLogbookVisits::whereNotNull('customer_name')
            ->where('customer_name', '!=', '')
            ->pluck('customer_name')
            ->toArray();

        // Merge and deduplicate case-insensitively
        $allCustomers = array_merge($visitCustomers, $planCustomers);
        $uniqueCustomers = [];
        $seenLowercase = [];

        foreach ($allCustomers as $customer) {
            $lowerCustomer = strtolower(trim($customer));
            if (!isset($seenLowercase[$lowerCustomer])) {
                $seenLowercase[$lowerCustomer] = true;
                $uniqueCustomers[] = trim($customer);
            }
        }

        // Sort alphabetically
        sort($uniqueCustomers, SORT_STRING | SORT_FLAG_CASE);

        return $uniqueCustomers;
    }

    /**
     * Check if current user is authorized to access dashboard
     */
    private function isAuthorizedUser()
    {
        $user = Auth::user();
        if (!$user) {
            return false;
        }

        $allowedUsers = array_merge(
            $this->getAdminNames(),
            $this->getDeptHeadNames()
        );

        return in_array($user->name, $allowedUsers);
    }

    /**
     * Check if user is admin
     */
    private function isAdmin($user)
    {
        if (!$user) {
            return false;
        }
        return in_array($user->name, $this->getAdminNames());
    }

    /**
     * Get department head mappings
     */
    private function getDepartmentHeadMappings(): array
    {
        return [
            'ANDIK TOTOK SISWOYO' => [
                'ANDIK TOTOK SISWOYO',
                'DANIA ISNAWATI',
                'FISKA CHRISMAS YUDHA',
                'TOTOK SISWOYO',
                'DWI KUNTORO',
                'YUNASIS PALGUNADI',
                'Hexapa Darmadi',
            ],
            'ILHAM CHOLID' => [
                'ILHAM CHOLID',
                'HERY HERMAWAN',
                'RIFQI RAHMAT DZATNIKA',
                'Sarah Ega Budi Astuti',
                'Dimas Aditya Priandana',
                'SONY STIAWAN',
            ],
            'JUN JOHAMIN PD' => [
                'JUN JOHAMIN PD',
                'YAN WELEM MANGINSELA',
                'WULYO EKO PRASETYO',
                'SENDY PRABOWO',
            ],
            'YULMAI RIDO WINANDA' => [
                'YULMAI RIDO WINANDA',
                'YAN WELEM MANGINSELA',
                'WULYO EKO PRASETYO',
                'SENDY PRABOWO',
                'HERY HERMAWAN',
                'RIFQI RAHMAT DZATNIKA',
                'Sarah Ega Budi Astuti',
                'Dimas Aditya Priandana',
                'SONY STIAWAN',
            ],
        ];
    }

    /**
     * Get region mappings
     */
    private function getRegionMappings(): array
    {
        return [
            'Region 1' => [
                'YAN WELEM MANGINSELA',
                'WULYO EKO PRASETYO',
                'SENDY PRABOWO',
                'Hexapa Darmadi',
            ],
            'Region 2' => [
                'HERY HERMAWAN',
                'RIFQI RAHMAT DZATNIKA',
                'Sarah Ega Budi Astuti',
                'Dimas Aditya Priandana',
                'SONY STIAWAN',
                'Hexapa Darmadi',
            ],
            'Region 3' => [
                'DANIA ISNAWATI',
                'FISKA CHRISMAS YUDHA',
                'TOTOK SISWOYO',
                'Hexapa Darmadi',
            ],
            'Region 4' => [
                'DWI KUNTORO',
                'YUNASIS PALGUNADI',
                'Hexapa Darmadi',
            ],
        ];
    }

    /**
     * Get department head names
     */
    private function getDeptHeadNames(): array
    {
        return [
            'ANDIK TOTOK SISWOYO',
            'ILHAM CHOLID',
            'JUN JOHAMIN PD',
            'YULMAI RIDO WINANDA',
        ];
    }

    /**
     * Get admin names
     */
    private function getAdminNames(): array
    {
        return [
            'ADMINISTRATOR',
            'ADMINSTRATOR',
        ];
    }
}
