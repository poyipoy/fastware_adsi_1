# Pemeriksaan setelah pemasangan

- [ ] 4 master item, 1 kategori, minimum/maksimum dan atribut benar; seluruh saldo nol.
- [ ] Tujuh tabel transaksi/sequence kosong, kartu legacy kosong, verifier NPK 5639/5439/5472 aktif, 23 migration Warehouse masing-masing tercatat sekali.
- [ ] Administrator, akun departemen resmi dan akses khusus existing memperoleh kemampuan sesuai source; akun di luar akses ditolak pada URL langsung.
- [ ] Semua menu dan halaman Warehouse terbuka tanpa class-not-found, Vite manifest missing, error CSRF atau HTTP 500.
- [ ] Stock In Baru menjadi pending tanpa saldo; verifier berhak memvalidasi dan hanya satu ledger terbentuk.
- [ ] Stock Out dan pengembalian Bekas atomik; stok negatif ditolak; submit ulang tidak menggandakan transaksi.
- [ ] Transfer internal melalui Stock In menghormati reservation; validasi, selisih dan cancel sesuai aturan existing.
- [ ] Adjustment/opening balance/reversal memerlukan verifier yang tepat.
- [ ] Riwayat, detail, dashboard, reporting dan Excel benar, termasuk saldo nol/no-data.
- [ ] Scanner item/NPK fisik Enter/Tab, keyboard, desktop dan mobile 360/390px diperiksa.
- [ ] Public/build dan manifest cocok; menu modul lain tetap tampil; foto baru bisa diunggah/ditampilkan.

Transaksi smoke production harus mengikuti prosedur operasional. Jangan menghapus ledger production setelah smoke; gunakan lingkungan staging atau reversal yang berwenang.
