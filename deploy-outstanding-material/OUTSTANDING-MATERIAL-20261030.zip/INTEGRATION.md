# Panduan Integrasi Shared Files

Paket ini menyediakan berkas shared utuh yang sudah diselaraskan, sekaligus file snippet terpisah:

## 1. File Shared Utuh
- `routes/web.php`
- `resources/views/layout.blade.php`
- `app/Enums/ProcurementMenuAccessGroup.php`

Berkas ini telah disanitasi sehingga hanya memuat rute dan navigasi produksi yang valid tanpa membawa draf pekerjaan modul lain yang belum dirilis.

## 2. File Snippet Terpisah
Bila Anda lebih memilih melakukan merge kode manual pada server target:
- `snippets/routes_web_snippet.php`: Potongan route group `Route::prefix('outstanding-materials')`.
- `snippets/layout_menu_snippet.blade.php`: Potongan tag `<li>` menu navigasi Outstanding Material.