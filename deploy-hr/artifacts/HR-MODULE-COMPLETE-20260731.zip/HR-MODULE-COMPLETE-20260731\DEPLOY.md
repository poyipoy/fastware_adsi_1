# Panduan Deploy Modul HR

## Prasyarat

- Laravel 10 dan dependency Composer/npm project tujuan sudah tersedia.
- Tabel bersama `users`, `roles`, `mst_departments`, dan `mst_sections` sudah tersedia.
- Backup source dan database tujuan sebelum merge.
- Periksa perubahan lokal pada `routes/web.php`, `routes/api.php`, controller dashboard, layout, provider, dan model `User`; file tersebut mengandung integrasi lintas modul dan tidak boleh ditimpa buta.

## Database

Paket menyediakan:

1. migration Laravel terkait pada `source/database/migrations`;
2. snapshot schema-only di `database/sql/hr_schema_snapshot_20260731.sql`.

Snapshot SQL tidak memuat data karyawan, credential, atau isi master. Gunakan snapshot hanya untuk instalasi schema baru/referensi. Untuk database existing, gunakan migration satu per satu setelah `php artisan migrate:status` dan verifikasi schema aktual. Migration `2026_07_01_000001_migrate_pd_pengajuan_to_ids.php` harus direkonsiliasi terlebih dahulu karena schema existing dapat sudah menggunakan kolom ID walaupun status migration masih pending.

## Urutan merge

1. Bandingkan `manifest-files.txt` dengan repository tujuan.
2. Merge model, enum, service, request, export, controller, view, dan asset.
3. Merge route/provider/layout secara manual.
4. Terapkan hanya migration yang belum terpasang.
5. Jalankan:

```text
composer dump-autoload
php artisan optimize:clear
php artisan route:list
php artisan view:cache
php artisan migrate:status
php artisan test
```

## Catatan data

- `users.is_active = 0` berarti aktif pada aplikasi ini.
- NPK `0` dianggap belum tersedia.
- Full-HR mengikuti `HRRoleAccessService`, saat paket dibuat adalah user ID 1 dan 91.
- Sharing Knowledge menggunakan pivot `mst_pd_pengajuan_participants` dengan fallback legacy `mst_pd_pengajuans.id_user`.
- Snapshot tidak menyertakan data master competency/job position; data tersebut harus dipertahankan dari database tujuan atau dipindahkan melalui prosedur data terpisah.
