# Paket Lengkap Modul HR

Folder hasil build berisi source aktif untuk:

- Base Competency dan master/mapping job position;
- Working Experience;
- Training Development / People Development;
- evaluasi dan history training;
- Dashboard TCPD web, API, export, dan authorization;
- menu HR, layout, server-driven navigation, asset, migration, serta test terkait.

## Struktur hasil

- `source/`: file aplikasi dengan path repository asli.
- `database/sql/`: snapshot schema MySQL tanpa data pengguna.
- `manifest-files.txt`: daftar source yang masuk paket.
- `SHA256SUMS.txt`: checksum seluruh source.
- `DEPLOY.md`: urutan pemasangan dan pemeriksaan.

File bertanggal `1225_*` dan backup Dashboard TCPD lama tidak disertakan.
Paket ini adalah paket merge untuk repository Fastware, bukan aplikasi Laravel mandiri.
