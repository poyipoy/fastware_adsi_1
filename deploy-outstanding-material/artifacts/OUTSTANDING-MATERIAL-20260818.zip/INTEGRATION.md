# File shared versi penuh

Paket ini tidak lagi memakai fragmen. Tiga file shared sudah tersedia sebagai file penuh pada path deploy finalnya:

1. `routes/web.php`
2. `app/Enums/ProcurementMenuAccessGroup.php`
3. `resources/views/layout.blade.php`

Sebelum menyalin paket, backup tiga file yang sama di target. Salin file penuh dari paket hanya ke target dengan baseline aplikasi yang sesuai dengan source paket ini; file tersebut akan mengganti seluruh isi file target.

Builder menghapus seluruh route group dan menu Warehouse dari dua file shared yang relevan. Dengan demikian, ZIP tidak membawa kode atau referensi Warehouse yang masih dalam pengembangan.

`app/Models/User.php` tetap tidak disertakan sebagai replacement. Pastikan target telah memiliki relasi `userJobPositions()` yang dipakai oleh `OutstandingMaterialAccessService` untuk mendeteksi Sales aktif.
