-- =============================================================================
-- Outstanding Material Idempotent Archive Patch (FOR EXISTING DATABASES)
-- Safe to execute repeatedly. Does not drop or delete existing data.
-- =============================================================================

DELIMITER $$

DROP PROCEDURE IF EXISTS `patch_outstanding_material_archive`$$
CREATE PROCEDURE `patch_outstanding_material_archive`()
BEGIN
    -- 1. Add archived_at to outstanding_material_invoices if missing
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = DATABASE() 
          AND table_name = 'outstanding_material_invoices' 
          AND column_name = 'archived_at'
    ) THEN
        ALTER TABLE `outstanding_material_invoices` 
        ADD COLUMN `archived_at` timestamp NULL DEFAULT NULL AFTER `document_review_required`;
    END IF;

    -- 2. Add om_invoices_archived_at_idx index if missing
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.statistics 
        WHERE table_schema = DATABASE() 
          AND table_name = 'outstanding_material_invoices' 
          AND index_name = 'om_invoices_archived_at_idx'
    ) THEN
        ALTER TABLE `outstanding_material_invoices` 
        ADD INDEX `om_invoices_archived_at_idx` (`archived_at`);
    END IF;

    -- 3. Add om_delay_eta_wh_idx index to outstanding_materials if missing
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.statistics 
        WHERE table_schema = DATABASE() 
          AND table_name = 'outstanding_materials' 
          AND index_name = 'om_delay_eta_wh_idx'
    ) THEN
        ALTER TABLE `outstanding_materials` 
        ADD INDEX `om_delay_eta_wh_idx` (`estimasi_delay_eta_warehouse`);
    END IF;

    -- 4. Add archived_at to outstanding_materials if missing
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = DATABASE() 
          AND table_name = 'outstanding_materials' 
          AND column_name = 'archived_at'
    ) THEN
        ALTER TABLE `outstanding_materials` 
        ADD COLUMN `archived_at` timestamp NULL DEFAULT NULL AFTER `keterangan`;
    END IF;

    -- 5. Add om_materials_archived_at_idx index to outstanding_materials if missing
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.statistics 
        WHERE table_schema = DATABASE() 
          AND table_name = 'outstanding_materials' 
          AND index_name = 'om_materials_archived_at_idx'
    ) THEN
        ALTER TABLE `outstanding_materials` 
        ADD INDEX `om_materials_archived_at_idx` (`archived_at`);
    END IF;

    -- 6. Synchronize materials whose invoice header is already archived
    UPDATE `outstanding_materials` m
    INNER JOIN `outstanding_material_invoices` i ON i.id = m.invoice_id
    SET m.archived_at = i.archived_at
    WHERE i.archived_at IS NOT NULL AND m.archived_at IS NULL;

END$$

DELIMITER ;

CALL `patch_outstanding_material_archive`();
DROP PROCEDURE `patch_outstanding_material_archive`;