<?php

namespace App\Services\KnowledgeManagement;

use App\Enums\KnowledgeManagement\KmReadStatus;
use App\Models\KmPengajuan;
use App\Models\KmTransaksi;
use App\Models\User;
use DomainException;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class KmReadingService
{
    public function __construct(
        private readonly KmAccessService $access,
        private readonly KmPointLedgerService $ledger,
    ) {
    }

    /**
     * @return array<string, bool|int|null>
     */
    public function markStarted(User $user, KmPengajuan $document): array
    {
        return DB::transaction(function () use ($user, $document): array {
            $lockedDocument = $this->lockAccessibleDocument($user, $document);
            $transaction = $this->lockOrCreateTransaction(
                $user,
                $lockedDocument,
                KmReadStatus::READING,
            );

            $alreadyCompleted = $transaction->readStatus() === KmReadStatus::COMPLETED
                || $transaction->points_awarded_at !== null;

            if (! $alreadyCompleted && $transaction->readStatus() !== KmReadStatus::READING) {
                $transaction->forceFill([
                    'status' => KmReadStatus::READING->value,
                    'modified_by' => $user->getKey(),
                ])->save();
            }

            $this->incrementDocumentView($lockedDocument, $transaction);

            return [
                'already_completed' => $alreadyCompleted,
                'points_awarded' => 0,
                ...$this->progressState($transaction, $lockedDocument),
            ];
        });
    }

    /**
     * @param  array{last_page: int, pages_total: int, pages: list<int>, active_delta: int}  $progress
     * @return array<string, bool|int|null>
     */
    public function updateProgress(User $user, KmPengajuan $document, array $progress): array
    {
        return DB::transaction(function () use ($user, $document, $progress): array {
            $lockedDocument = $this->lockAccessibleDocument($user, $document);
            if (! $this->access->isPublishedDocumentEligible($user, $lockedDocument)) {
                throw new AuthorizationException('Progress hanya dapat disimpan untuk materi yang dipublikasikan.');
            }

            $transaction = $this->lockOrCreateTransaction(
                $user,
                $lockedDocument,
                KmReadStatus::READING,
            );
            if ($transaction->readStatus() === KmReadStatus::COMPLETED) {
                return $this->progressState($transaction, $lockedDocument);
            }
            if ($transaction->readStatus() !== KmReadStatus::READING) {
                throw new DomainException('Status baca transaksi Knowledge Management tidak valid.');
            }

            $pagesTotal = (int) $progress['pages_total'];
            $lastPage = (int) $progress['last_page'];
            $pages = array_values(array_unique(array_map('intval', $progress['pages'])));
            if ($pagesTotal <= 0 || $lastPage <= 0 || $lastPage > $pagesTotal) {
                throw new DomainException('Nomor halaman progress tidak valid.');
            }
            foreach ($pages as $page) {
                if ($page <= 0 || $page > $pagesTotal) {
                    throw new DomainException('Daftar halaman progress tidak valid.');
                }
            }

            if ($transaction->pages_total !== null && (int) $transaction->pages_total !== $pagesTotal) {
                throw new DomainException(
                    'Jumlah halaman dokumen berubah. Tutup viewer lalu buka kembali dokumen.'
                );
            }

            $bitmap = $this->decodeBitmap($transaction->unique_pages, $pagesTotal);
            foreach ([...$pages, $lastPage] as $page) {
                $this->setPageBit($bitmap, $page);
            }
            $uniqueCount = $this->countPageBits($bitmap, $pagesTotal);
            $progressPercent = min(100, (int) floor(($uniqueCount / $pagesTotal) * 100));
            $maximumDelta = max(
                0,
                (int) config('knowledge_management.reading.maximum_active_delta_seconds', 120),
            );
            $activeDelta = min(max(0, (int) $progress['active_delta']), $maximumDelta);

            $transaction->forceFill([
                'last_page' => max((int) ($transaction->last_page ?? 0), $lastPage),
                'pages_total' => $pagesTotal,
                'unique_pages' => base64_encode($bitmap),
                'unique_pages_count' => $uniqueCount,
                'active_seconds' => (int) ($transaction->active_seconds ?? 0) + $activeDelta,
                'progress_percent' => $progressPercent,
                'last_progress_at' => now(),
                'modified_by' => $user->getKey(),
            ])->save();

            return $this->progressState($transaction->refresh(), $lockedDocument);
        }, 3);
    }

    /**
     * @return array{already_completed: bool, points_awarded: int}
     */
    public function complete(User $user, KmPengajuan $document): array
    {
        return DB::transaction(function () use ($user, $document): array {
            $lockedDocument = KmPengajuan::query()
                ->whereKey($document->getKey())
                ->lockForUpdate()
                ->firstOrFail();
            $lockedUser = User::query()->whereKey($user->getKey())->lockForUpdate()->firstOrFail();
            if (! $this->access->isPublishedDocumentEligible($lockedUser, $lockedDocument)) {
                throw new AuthorizationException('Dokumen tidak memenuhi syarat untuk diselesaikan.');
            }

            $transaction = $this->lockOrCreateTransaction(
                $lockedUser,
                $lockedDocument,
                KmReadStatus::READING,
            );

            if ($transaction->readStatus() === KmReadStatus::COMPLETED
                || $transaction->points_awarded_at !== null) {
                return [
                    'already_completed' => true,
                    'points_awarded' => 0,
                ];
            }

            if ($transaction->readStatus() !== KmReadStatus::READING) {
                throw new DomainException('Status baca transaksi Knowledge Management tidak valid.');
            }
            if ($lockedDocument->isPreviewableFile()
                && ! $this->isCompletionEligible($transaction, $lockedDocument)) {
                $requiredPages = $this->requiredUniquePages((int) ($transaction->pages_total ?? 0));
                $requiredSeconds = $this->requiredActiveSeconds((int) ($transaction->pages_total ?? 0));
                throw new DomainException(sprintf(
                    'Belum memenuhi syarat selesai: buka minimal %d halaman unik dan baca aktif minimal %d detik.',
                    $requiredPages,
                    $requiredSeconds,
                ));
            }

            $points = max(0, (int) config('knowledge_management.points.completion', 5));
            $completedAt = now();
            $awarded = $this->ledger->award(
                $lockedUser,
                'completion',
                'completion:'.$lockedUser->getKey().':'.$lockedDocument->getKey(),
                $points,
                (int) $lockedDocument->getKey(),
                null,
                ['completion_type' => 'official'],
                $lockedUser,
            );

            $transaction->forceFill([
                'status' => KmReadStatus::COMPLETED->value,
                'poin' => $points,
                'completed_at' => $completedAt,
                'points_awarded_at' => $completedAt,
                'modified_by' => $lockedUser->getKey(),
            ])->save();

            return [
                'already_completed' => false,
                'points_awarded' => $awarded ? $points : 0,
            ];
        }, 3);
    }

    private function lockAccessibleDocument(User $user, KmPengajuan $document): KmPengajuan
    {
        $lockedDocument = KmPengajuan::query()
            ->whereKey($document->getKey())
            ->lockForUpdate()
            ->firstOrFail();
        if (! $this->access->canView($user, $lockedDocument)) {
            throw new AuthorizationException('Dokumen Knowledge Management tidak dapat diakses.');
        }

        return $lockedDocument;
    }

    private function lockOrCreateTransaction(
        User $user,
        KmPengajuan $document,
        KmReadStatus $initialStatus,
    ): KmTransaksi {
        $query = KmTransaksi::query()
            ->where('id_user', $user->getKey())
            ->where('id_km_pengajuan', $document->getKey());

        $transaction = (clone $query)->lockForUpdate()->first();
        if ($transaction !== null) {
            return $transaction;
        }

        try {
            KmTransaksi::query()->create([
                'id_user' => $user->getKey(),
                'id_km_pengajuan' => $document->getKey(),
                'level' => 0,
                'status' => $initialStatus->value,
                'modified_by' => $user->getKey(),
            ]);
        } catch (QueryException $exception) {
            if (! $this->isUniqueConstraintViolation($exception)) {
                throw $exception;
            }
        }

        return (clone $query)->lockForUpdate()->firstOrFail();
    }

    /**
     * @return array{last_page: int|null, pages_total: int|null, unique_pages_count: int, active_seconds: int, progress_percent: int, completion_eligible: bool}
     */
    private function progressState(KmTransaksi $transaction, KmPengajuan $document): array
    {
        return [
            'last_page' => $transaction->last_page === null ? null : (int) $transaction->last_page,
            'pages_total' => $transaction->pages_total === null ? null : (int) $transaction->pages_total,
            'unique_pages_count' => (int) ($transaction->unique_pages_count ?? 0),
            'active_seconds' => (int) ($transaction->active_seconds ?? 0),
            'progress_percent' => (int) ($transaction->progress_percent ?? 0),
            'completion_eligible' => $this->isCompletionEligible($transaction, $document),
        ];
    }

    private function isCompletionEligible(KmTransaksi $transaction, KmPengajuan $document): bool
    {
        if ($transaction->readStatus() === KmReadStatus::COMPLETED) {
            return true;
        }
        if (! $document->isPreviewableFile()) {
            return true;
        }

        $pagesTotal = (int) ($transaction->pages_total ?? 0);

        return $pagesTotal > 0
            && (int) ($transaction->unique_pages_count ?? 0) >= $this->requiredUniquePages($pagesTotal)
            && (int) ($transaction->active_seconds ?? 0) >= $this->requiredActiveSeconds($pagesTotal);
    }

    private function requiredUniquePages(int $pagesTotal): int
    {
        $ratio = min(1, max(0, (float) config('knowledge_management.reading.unique_page_ratio', 0.9)));

        return $pagesTotal > 0 ? (int) ceil($ratio * $pagesTotal) : 1;
    }

    private function requiredActiveSeconds(int $pagesTotal): int
    {
        $minimum = max(0, (int) config('knowledge_management.reading.minimum_active_seconds', 60));
        $perPage = max(0, (int) config('knowledge_management.reading.seconds_per_page', 20));
        $maximum = max($minimum, (int) config('knowledge_management.reading.maximum_required_seconds', 900));

        return max($minimum, min($perPage * max(1, $pagesTotal), $maximum));
    }

    private function decodeBitmap(?string $encoded, int $pagesTotal): string
    {
        $bytesRequired = (int) ceil($pagesTotal / 8);
        if ($encoded === null || $encoded === '') {
            return str_repeat("\0", $bytesRequired);
        }

        $decoded = base64_decode($encoded, true);
        if ($decoded === false || strlen($decoded) > $bytesRequired) {
            throw new DomainException('Bitmap progress tersimpan tidak valid. Hubungi administrator.');
        }

        return str_pad($decoded, $bytesRequired, "\0");
    }

    private function setPageBit(string &$bitmap, int $page): void
    {
        $offset = $page - 1;
        $byte = intdiv($offset, 8);
        $bit = $offset % 8;
        $bitmap[$byte] = chr(ord($bitmap[$byte]) | (1 << $bit));
    }

    private function countPageBits(string $bitmap, int $pagesTotal): int
    {
        $count = 0;
        $bytes = strlen($bitmap);
        for ($index = 0; $index < $bytes; $index++) {
            $count += substr_count(decbin(ord($bitmap[$index])), '1');
        }

        return min($count, $pagesTotal);
    }

    private function incrementDocumentView(KmPengajuan $document, KmTransaksi $transaction): void
    {
        $now = now();
        try {
            DB::table('km_lihat_bukus')->insert([
                'id_km_transaksi' => $transaction->getKey(),
                'id_km_pengajuan' => $document->getKey(),
                'jumlah_lihat' => 1,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            return;
        } catch (QueryException $exception) {
            if (! $this->isUniqueConstraintViolation(
                $exception,
                'km_lihat_bukus_document_unique',
            )) {
                throw $exception;
            }
        }

        DB::table('km_lihat_bukus')
            ->where('id_km_pengajuan', $document->getKey())
            ->update([
                'jumlah_lihat' => DB::raw('jumlah_lihat + 1'),
                'updated_at' => $now,
            ]);
    }

    private function isUniqueConstraintViolation(
        QueryException $exception,
        string $constraint = 'km_transaksis_user_document_unique',
    ): bool {
        return in_array((string) $exception->getCode(), ['23000', '23505'], true)
            && str_contains(strtolower($exception->getMessage()), strtolower($constraint));
    }
}
