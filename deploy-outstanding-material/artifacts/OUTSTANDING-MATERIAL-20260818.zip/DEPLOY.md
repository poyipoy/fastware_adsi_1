# Panduan Deploy Outstanding Material

## Prasyarat

- Target adalah aplikasi Laravel yang sudah memiliki tabel `users` dengan primary key `bigint unsigned`.
- Target memiliki `maatwebsite/excel` (`^3.1`) dan dependensi aplikasi Laravel yang sesuai.
- Middleware `role:outstanding_material` sudah didukung oleh aplikasi target.
- Relasi `User::userJobPositions()` serta tabel Job Position/Department aktif sudah tersedia untuk akses Sales.
- Direktori `storage/app` dapat ditulis oleh proses PHP; paket tidak membawa dokumen upload lama.
- Lakukan backup source dan database target sebelum deploy.

## 1. Verifikasi paket

1. Extract ZIP ke folder staging, bukan langsung ke root production.
2. Cocokkan `MANIFEST.txt` dan `SHA256SUMS.txt`.
3. Pastikan ZIP tidak berisi `vendor`, `.env`, `storage`, `tests`, `database/migrations`, atau konten Warehouse. Builder paket secara khusus menghapus route dan menu Warehouse dari tiga file shared penuh.

## 2. Integrasi source

1. Salin `app/`, `public/`, `resources/`, dan `routes/` ke aplikasi target dengan menjaga struktur path.
2. `routes/web.php`, `app/Enums/ProcurementMenuAccessGroup.php`, dan `resources/views/layout.blade.php` dalam paket adalah versi penuh yang sudah digabung tanpa konten Warehouse. Backup tiga file target tersebut, pastikan baseline target sesuai, lalu ganti dengan versi paket sebagaimana dijelaskan di `INTEGRATION.md`.
3. Jalankan:

```bash
composer dump-autoload --optimize
php artisan view:clear
php artisan route:list --path=outstanding-material
```

Jika target memakai route cache, jalankan `php artisan route:clear`, lalu buat ulang route cache sesuai prosedur deployment target. Setelah deploy Blade/JavaScript, lakukan hard refresh browser.

## 3. Instalasi database baru

1. Jalankan `database/sql/00_preflight.sql` pada database target.
2. Lanjut hanya bila kedua hasil requirement bernilai `PASS` dan tabel Outstanding Material belum ada.
3. Jalankan `database/sql/01_outstanding_material_schema.sql` satu kali.

SQL ini hanya membuat struktur `outstanding_material_invoices` dan `outstanding_materials`; tidak ada data, migration ledger, atau data upload yang dibawa.

Jangan menjalankan script ini jika salah satu tabel Outstanding Material sudah ada. Paket ini tidak menyertakan migration Laravel dan tidak menulis tabel `migrations`. Sebelum menjalankan migration global pada masa depan, rekonsiliasikan enam migration Outstanding Material asli terlebih dahulu agar tidak terjadi konflik schema.

## 4. Pemeriksaan pascadeploy

- Route Outstanding Material tampil pada hasil `route:list`.
- User berhak dapat membuka menu; Sales memiliki akses view/export/download sesuai posisi aktifnya.
- User pengelola dapat membuat, mengubah, dan menghapus invoice dengan konfirmasi.
- Import, export, download PL/MTC, dan filter tabel dapat digunakan.

## Rollback

Pulihkan source shared-file dan source modul dari backup sebelum deploy. Jangan menghapus tabel atau data production sebagai rollback rutin; gunakan backup database dan prosedur perubahan schema yang disetujui bila rollback database memang diperlukan.
