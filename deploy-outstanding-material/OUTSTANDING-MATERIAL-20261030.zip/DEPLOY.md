# Panduan Deployment Modul Outstanding Material (Production)
**Release:** OUTSTANDING-MATERIAL-20261030  
**Target:** Root Direktori Laravel Server Produksi

---

## Ringkasan Perubahan pada Rilis Ini
1. **Perbaikan Format Nilai 0 pada Export Excel:**
   - Kolom numerik (`thickness`, `width`, `diameter`, `qty_pcs`, `est_qty_kg`) yang bernilai NULL/kosong diekspor sebagai float numerik `0.0` (tipe sel numerik Excel, bukan teks string `"0"`).
   - Nilai eksisting `0` dan nilai non-zero tetap terjaga presisinya.
2. **Pembaruan Bulk Update Material (5 Kolom ETA Tambahan):**
   - Modal Bulk Update Materials kini mendukung pembaruan 5 field: *Estimasi ETA Port, Estimasi ETA Warehouse, Estimasi Bulan ETA, Estimasi Delay ETA Port, dan Estimasi Delay ETA Warehouse*.
   - Aturan *Keep Current*: field yang dikosongkan tidak mengubah nilai material berjalan.
   - Dilengkapi validasi tanggal kalender `YYYY-MM-DD` dan proteksi kepemilikan invoice.
3. **Halaman Khusus Material Diarsipkan (Archived Materials):**
   - Rute baru: `/outstanding-materials/archived-materials`.
   - Menampilkan seluruh material yang invoice induknya telah berstatus diarsipkan secara read-only dengan DataTables, server-side pagination, dan filter Select2.
   - Restoring invoice dari halaman *Archived Invoices* secara otomatis mengembalikan seluruh material terkait ke daftar monitoring aktif.

---

## Langkah 1: Backup Sebelum Deployment
Selalu lakukan backup sebelum melakukan update di server production:
1. Backup database MySQL target (misal: via `mysqldump` atau phpMyAdmin export).
2. Backup berkas shared target:
   - `routes/web.php`
   - `resources/views/layout.blade.php`

---

## Langkah 2: Eksekusi Skrip Database
Buka database target via phpMyAdmin, Adminer, atau MySQL CLI:

- **Kasus A: Tabel Outstanding Material sudah ada dari versi sebelumnya:**
  Jalankan berkas:
  ```text
  database/sql/02_outstanding_material_patch_archive.sql
  ```
  *(Skrip ini aman, idempotent, dan tidak menghapus data berjalan. Skrip akan menambahkan kolom `archived_at` dan indeks pendukung pada tabel `outstanding_material_invoices` dan `outstanding_materials`).*

- **Kasus B: Instalasi baru dari nol (tabel belum pernah ada):**
  1. Jalankan `database/sql/00_preflight.sql` untuk memastikan tabel `users` siap.
  2. Jalankan `database/sql/01_outstanding_material_fresh_schema.sql`.

---

## Langkah 3: Salin Berkas ke Root Laravel Production
Ekstrak isi ZIP langsung ke root direktori aplikasi Laravel Anda di server:

1. **Berkas Modul Otomatis Terganti / Bertambah Sesuai Jalur:**
   - `app/` → `app/`
   - `public/` → `public/`
   - `resources/` → `resources/`
2. **Berkas Bersama (Shared Files):**
   - **Opsi Cepat (Timpa File):** Salin file `routes/web.php` dan `resources/views/layout.blade.php` dari paket.
   - **Opsi Manual (Merge Snippet):** Jika server produksi memiliki penyesuaian route/layout lokal lain, Anda dapat menggunakan potongan kode siap pakai dari:
     - `snippets/routes_web_snippet.php` (paste ke grup middleware auth di `routes/web.php`).
     - `snippets/layout_menu_snippet.blade.php` (paste ke menu navigasi di `resources/views/layout.blade.php`).

---

## Langkah 4: Optimasi & Pembersihan Cache Laravel
Jalankan perintah berikut di terminal server production:
```bash
composer dump-autoload --optimize
php artisan route:clear
php artisan view:clear
php artisan config:clear
php artisan cache:clear
```

Jika aplikasi target menggunakan route caching di production, jalankan:
```bash
php artisan route:cache
```

---

## Langkah 5: Verifikasi Pasca-Deployment
1. Jalankan perintah pengecekan route:
   ```bash
   php artisan route:list --path=outstanding-materials
   ```
   Pastikan route `archived-materials` dan `archived-invoices` terdaftar.
2. Buka browser dan login sebagai user yang berhak (Procurement/Sales).
3. Buka menu **Outstanding Material**:
   - Uji tombol **Export Excel**: pastikan sel kosong pada tebal/lebar muncul sebagai angka `0`.
   - Buka **Detail Invoice** → **Update Materials**: pastikan 5 field ETA baru muncul di modal dan berfungsi dengan mode *Keep Current*.
   - Buka menu/halaman **Archived Materials** (`/outstanding-materials/archived-materials`): pastikan tabel DataTables memuat daftar material arsip lengkap dengan filter Select2.