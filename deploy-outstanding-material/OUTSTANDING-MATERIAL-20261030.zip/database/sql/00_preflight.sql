-- =============================================================================
-- Outstanding Material Preflight Check (READ-ONLY)
-- Run this script first in MySQL GUI / phpMyAdmin.
-- =============================================================================

SELECT
    DATABASE() AS active_database,
    CASE
        WHEN EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = DATABASE() AND table_name = 'users'
        ) THEN 'PASS: table users exists'
        ELSE 'STOP: table users is required before installing Outstanding Material'
    END AS users_requirement,
    CASE
        WHEN EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = DATABASE() AND table_name = 'outstanding_materials'
        ) THEN 'TABLES_EXIST: use 02_outstanding_material_patch_archive.sql'
        ELSE 'FRESH_INSTALL: use 01_outstanding_material_fresh_schema.sql'
    END AS installation_mode;

SELECT
    table_name,
    table_rows,
    create_time
FROM information_schema.tables
WHERE table_schema = DATABASE()
  AND table_name IN ('users', 'outstanding_materials', 'outstanding_material_invoices')
ORDER BY table_name;