# Warehouse 20261022 — mulai di sini

Paket instalasi Warehouse pertama kali pada aplikasi Fastware yang sudah ada.
Cara deploy: upload file + phpMyAdmin. Production belum diakses atau diubah.

Hasil validasi dan batasannya ada di `docs/VALIDATION.md`. Suite Warehouse belum seluruhnya hijau; baca lima kegagalan test schema sebelum memutuskan aktivasi production.

1. Baca `docs/DEPLOY.md`, khususnya backup, maintenance, integrasi shared, dan privilege SQL.
2. Import `database/00_preflight.sql`, lalu `01_schema.sql`, `02_master_access.sql`, `03_postcheck.sql` **satu per satu** pada database aplikasi yang benar.
3. Upload `app/`, `bootstrap/`, `config/`, `resources/`, dan `routes/` sesuai path yang sama pada root Laravel. Upload `public/build/` ke folder public aktual.
4. File routes, layout, middleware, gates dan rate limiter sudah berupa file lengkap dengan integrasi Warehouse. Periksa kecocokan baseline file bersama production sebelum menggantinya; lihat `docs/DEPLOY.md`.
5. Hapus cache yang disebutkan dalam DEPLOY melalui File Manager, lalu jalankan smoke checklist sebelum membuka kembali akses.

Kode Warehouse berasal dari source aktif, termasuk perubahan lokal Validasi Stok terbaru. Struktur paket mengikuti root project; tidak ada direktori perantara runtime, shared-integration, atau support.
File SQL berada di database/. Migration asli berada di database/migrations/ sebagai rekam schema; pemasangan ini memakai SQL, bukan migrate umum. Tidak ada vendor, .env, backup database, seeder, command reset atau data transaksi di paket.
