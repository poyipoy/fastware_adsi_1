<?php

namespace App\Services\KnowledgeManagement;

use App\Enums\KnowledgeManagement\KmDocumentStatus;
use App\Enums\KnowledgeManagement\KmReadStatus;
use App\Models\KmKategori;
use App\Models\KmPengajuan;
use App\Models\KmTag;
use App\Models\KmTransaksi;
use App\Models\User;
use Carbon\CarbonImmutable;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Collection;

class KmDocumentQueryService
{
    public function __construct(
        private readonly KmAccessService $access,
        private readonly KmApprovalService $approval,
        private readonly KmPointLedgerService $ledger,
    ) {
    }

    public function paginateAuthoring(User $user): LengthAwarePaginator
    {
        $query = KmPengajuan::query()->with('user')->latest('id');

        if (! $this->access->hasFullAccess($user)) {
            $query->where('id_user', $user->getKey());
        }

        return $query->paginate(25)->withQueryString();
    }

    public function paginateApprovals(string $sort = 'oldest'): LengthAwarePaginator
    {
        $query = KmPengajuan::query()
            ->select('km_pengajuans.*')
            ->addSelect([
                'pending_since' => \App\Models\KmApprovalEvent::query()
                    ->select('acted_at')
                    ->whereColumn('km_pengajuan_id', 'km_pengajuans.id')
                    ->where('action', \App\Enums\KnowledgeManagement\KmApprovalAction::SUBMITTED->value)
                    ->orderByDesc('acted_at')
                    ->orderByDesc('id')
                    ->limit(1),
            ])
            ->with([
                'user',
                'kmKategori',
                'approvalEvents' => fn ($query) => $query->latest('acted_at'),
            ])
            ->whereIn('status', [
                KmDocumentStatus::PENDING_APPROVAL->value,
                KmDocumentStatus::PUBLISHED->value,
            ]);

        $query->orderByRaw(
            'CASE WHEN status = ? THEN 0 ELSE 1 END',
            [KmDocumentStatus::PENDING_APPROVAL->value],
        );
        if ($sort === 'newest') {
            $query->orderByDesc('pending_since')->orderByDesc('id');
        } else {
            $query->orderByRaw('pending_since IS NULL')->orderBy('pending_since')->orderBy('id');
        }

        $paginator = $query
            ->paginate(25)
            ->withQueryString();

        $dueDays = max(1, (int) config('knowledge_management.approval_sla.due_working_days', 3));
        $paginator->getCollection()->each(function (KmPengajuan $document) use ($dueDays): void {
            $waitingDays = $document->pending_since === null
                ? 0
                : $this->approval->workingDaysSince(CarbonImmutable::parse($document->pending_since));
            $document->setAttribute('waiting_working_days', $waitingDays);
            $document->setAttribute(
                'approval_overdue',
                $document->documentStatus() === KmDocumentStatus::PENDING_APPROVAL
                    && $waitingDays >= $dueDays,
            );
        });

        return $paginator;
    }

    public function find(int $documentId): KmPengajuan
    {
        return KmPengajuan::query()->findOrFail($documentId);
    }

    public function findForPayload(int $documentId): KmPengajuan
    {
        return KmPengajuan::query()
            ->with([
                'tags:id,name,slug',
                'coAuthors' => fn ($query) => $query
                    ->orderBy('name')
                    ->select(['users.id', 'users.name', 'users.email']),
            ])
            ->findOrFail($documentId);
    }

    public function findForApprovalPayload(int $documentId): KmPengajuan
    {
        return KmPengajuan::query()
            ->with([
                'tags:id,name,slug',
                'coAuthors' => fn ($query) => $query
                    ->orderBy('name')
                    ->select(['users.id', 'users.name', 'users.email']),
                'approvalEvents.actor',
            ])
            ->findOrFail($documentId);
    }

    /**
     * @return Collection<int, KmKategori>
     */
    public function categories(): Collection
    {
        return KmKategori::query()
            ->orderBy('nama_kategori')
            ->get(['id', 'nama_kategori']);
    }

    /**
     * @return array<string, mixed>
     */
    public function dashboardReferences(User $user): array
    {
        return [
            'leaderboard' => User::query()
                ->select(['id', 'name', 'km_total_poin'])
                ->orderByDesc('km_total_poin')
                ->limit(10)
                ->get(),
            'departmentLeaderboard' => $this->ledger->departmentLeaderboard(
                $user,
                10,
                (int) config('knowledge_management.points.department_minimum_cohort', 5),
            ),
            'continueReading' => KmTransaksi::query()
                ->with(['kmPengajuan.kmKategori'])
                ->where('id_user', $user->getKey())
                ->where('status', KmReadStatus::READING->value)
                ->whereHas('kmPengajuan', function ($query) use ($user): void {
                    $this->access->applyPublishedVisibility($query, $user);
                })
                ->orderByRaw('COALESCE(last_progress_at, updated_at) DESC')
                ->orderByDesc('id')
                ->limit(3)
                ->get(),
            'kategoris' => $this->categories(),
            'tags' => KmTag::query()->orderBy('name')->get(['id', 'name']),
        ];
    }
}
